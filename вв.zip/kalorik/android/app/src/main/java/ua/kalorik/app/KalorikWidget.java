package ua.kalorik.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

// Віджет робочого столу: скільки калорій залишилось + кнопки «додати їжу» і «записати голосом».
// Дані бере зі сховища програми (Capacitor Preferences), інтернет і сервер не потрібні.
public class KalorikWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) manager.updateAppWidget(id, build(context));
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, KalorikWidget.class));
        for (int id : ids) manager.updateAppWidget(id, build(context));
    }

    private static PendingIntent link(Context context, String url, int code) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        intent.setClass(context, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static String[] words(String lang) {
        // 0 — «залишилось», 1 — «понад норму», 2 — «З'їдено», 3 — «+ Їжа», 4 — «Серія», 5 — «Відкрий Калорік»
        switch (lang) {
            case "en": return new String[]{"kcal left", "kcal over", "Eaten", "+ Food", "Streak", "Open Kalorik"};
            case "ru": return new String[]{"ккал осталось", "ккал сверх нормы", "Съедено", "+ Еда", "Серия", "Открой Калорик"};
            default: return new String[]{"ккал залишилось", "ккал понад норму", "З'їдено", "+ Їжа", "Серія", "Відкрий Калорік"};
        }
    }

    static RemoteViews build(Context context) {
        RemoteViews v = new RemoteViews(context.getPackageName(), R.layout.widget_kalorik);
        String lang = "uk";
        int norm = 0, eaten = 0, burned = 0, streak = 0;
        boolean has = false;
        try {
            SharedPreferences prefs = context.getSharedPreferences("CapacitorStorage", Context.MODE_PRIVATE);
            String raw = prefs.getString("kalorik_widget", null);
            if (raw != null) {
                JSONObject o = new JSONObject(raw);
                lang = o.optString("lang", "uk");
                norm = o.optInt("norm", 0);
                String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
                // Якщо записи за інший день — показуємо повну норму нового дня.
                if (today.equals(o.optString("date"))) {
                    eaten = o.optInt("eaten", 0);
                    burned = o.optInt("burned", 0);
                    streak = o.optInt("streak", 0);
                }
                has = norm > 0;
            }
        } catch (Exception ignored) {
            has = false;
        }
        String[] w = words(lang);
        if (has) {
            int left = norm + burned - eaten;
            int total = Math.max(1, norm + burned);
            v.setTextViewText(R.id.kcal_left, String.valueOf(Math.abs(left)));
            v.setTextViewText(R.id.caption, left >= 0 ? w[0] : w[1]);
            v.setTextViewText(R.id.info, w[2] + " " + eaten + " / " + (norm + burned) + (streak > 0 ? "  ·  🔥 " + streak : ""));
            v.setProgressBar(R.id.bar, 100, Math.max(0, Math.min(100, eaten * 100 / total)), false);
        } else {
            v.setTextViewText(R.id.kcal_left, "—");
            v.setTextViewText(R.id.caption, w[5]);
            v.setTextViewText(R.id.info, "");
            v.setProgressBar(R.id.bar, 100, 0, false);
        }
        v.setTextViewText(R.id.btn_add, w[3]);
        v.setOnClickPendingIntent(R.id.btn_add, link(context, "kalorik://add", 1));
        v.setOnClickPendingIntent(R.id.btn_voice, link(context, "kalorik://voice", 2));
        v.setOnClickPendingIntent(R.id.widget_root, link(context, "kalorik://open", 3));
        return v;
    }
}
