import { S, save } from './store.js';

const API = 'https://generativelanguage.googleapis.com/v1beta';

// Фото зменшуємо до 1024 px — так запит швидший і дешевший, а точності вистачає.
export function fileToJpegBase64(file, max = 1024) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      const dataUrl = c.toDataURL('image/jpeg', 0.85);
      res({ dataUrl, base64: dataUrl.split(',')[1] });
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error('Не вдалося прочитати фото')); };
    img.src = url;
  });
}

// Назви моделей у Google змінюються, тому беремо актуальну зі списку, а не зашиту в код.
async function pickModel(key) {
  const r = await fetch(`${API}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } });
  if (!r.ok) throw await apiError(r);
  const list = ((await r.json()).models || [])
    .filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
    .map(m => m.name.replace('models/', ''))
    .filter(n => n.startsWith('gemini') && !/image|tts|live|audio|embed|robot|computer|aqa/.test(n));
  const ver = n => parseFloat((n.match(/gemini-(\d+(\.\d+)?)/) || [0, 0])[1]);
  const score = n => ver(n) * 100 + (/flash/.test(n) ? 20 : 0) - (/lite/.test(n) ? 10 : 0) - (/preview|exp|latest/.test(n) ? 30 : 0) - (/pro/.test(n) ? 15 : 0);
  list.sort((a, b) => score(b) - score(a));
  if (!list.length) throw new Error('Для цього ключа немає доступних моделей Gemini');
  return list[0];
}

async function apiError(r) {
  let msg = '';
  try { msg = (await r.json()).error?.message || ''; } catch { /* тіло не JSON */ }
  if (r.status === 400 && /API key/i.test(msg)) return new Error('Ключ Gemini неправильний. Перевір його в налаштуваннях.');
  if (r.status === 403) return new Error('Ключ Gemini не має доступу. Перевір його в Google AI Studio.');
  if (r.status === 429) return new Error('Вичерпано ліміт запитів Gemini. Спробуй трохи пізніше.');
  return new Error(`Помилка Gemini (${r.status}). ${msg}`.trim());
}

const SCHEMA = {
  type: 'OBJECT',
  properties: {
    items: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' }, grams: { type: 'NUMBER' }, kcal: { type: 'NUMBER' },
          protein: { type: 'NUMBER' }, fat: { type: 'NUMBER' }, carbs: { type: 'NUMBER' },
        },
        required: ['name', 'grams', 'kcal', 'protein', 'fat', 'carbs'],
      },
    },
  },
  required: ['items'],
};

export async function analyzePhoto(base64, hint = '') {
  const key = S.settings.geminiKey.trim();
  if (!key) throw new Error('NO_KEY');
  if (!navigator.onLine) throw new Error('Немає інтернету. Аналіз фото працює лише онлайн.');
  const prompt = `Ти дієтолог. Визнач усі страви та продукти на фото. Для кожного оціни вагу порції в грамах і порахуй калорії, білки, жири та вуглеводи саме для цієї порції. Назви пиши українською, коротко. Якщо на фото немає їжі, поверни порожній список.${hint ? ` Уточнення від користувача: ${hint}` : ''}`;
  const body = JSON.stringify({
    contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: 'image/jpeg', data: base64 } }] }],
    generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.2 },
  });
  const call = model => fetch(`${API}/models/${model}:generateContent`, {
    method: 'POST', headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' }, body,
  });
  let model = S.settings.geminiModel || await pickModel(key);
  let r = await call(model);
  if (r.status === 404) { model = await pickModel(key); r = await call(model); } // збережену модель могли вимкнути
  if (!r.ok) throw await apiError(r);
  if (S.settings.geminiModel !== model) { S.settings.geminiModel = model; save(); }
  const data = await r.json();
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
  let items;
  try { items = JSON.parse(text).items; } catch { throw new Error('Gemini повернув незрозумілу відповідь. Спробуй ще раз.'); }
  return (items || []).filter(i => i.name).map(i => ({
    name: String(i.name), g: Math.round(+i.grams || 0), kcal: Math.round(+i.kcal || 0),
    p: Math.round((+i.protein || 0) * 10) / 10, f: Math.round((+i.fat || 0) * 10) / 10, c: Math.round((+i.carbs || 0) * 10) / 10,
  }));
}
