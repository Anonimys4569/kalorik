import { S, save, uid, dayMut, touchRecent, lastWeight } from './store.js';
import { BASE_FOODS } from './foods.js';
import { scale, ACTS, actKcal, r1 } from './calc.js';
import { analyzePhoto, fileToJpegBase64 } from './ai.js';
import { startScan, stopScan, lookupBarcode } from './barcode.js';
import { ui, A, I, C, app, $, esc, num, fmt, MEALS, sheet, closeSheet, toast } from './ui.js';

const allFoods = () => [...S.foods, ...BASE_FOODS];
const getFood = id => allFoods().find(f => f.id === id);
const mealName = () => MEALS.find(m => m.id === ui.meal).name;
const mealByTime = () => { const h = new Date().getHours(); return h < 11 ? 'breakfast' : h < 16 ? 'lunch' : h < 21 ? 'dinner' : 'snack'; };
const head = (title, back) => `<div class="sh-head">${back ? `<button class="ic" data-a="${back}" aria-label="Назад">‹</button>` : ''}<h2>${esc(title)}</h2><button class="ic" data-a="closeSheet" aria-label="Закрити">✕</button></div>`;
const mealSeg = () => `<div class="seg">${MEALS.map(m => `<button class="${ui.meal === m.id ? 'on' : ''}" data-a="setMeal" data-v="${m.id}">${m.name}</button>`).join('')}</div>`;
const search = (q, list) => { const ws = q.toLowerCase().split(/\s+/).filter(Boolean); return list.filter(f => { const n = f.name.toLowerCase(); return ws.every(w => n.includes(w)); }); };
const macro = f => `Б ${f.p || 0} · Ж ${f.f || 0} · В ${f.c || 0}`;
function pushEntry(e) { dayMut(ui.date).entries.push({ id: uid(), meal: ui.meal, ...e }); save(); }

/* ---------- Додати їжу ---------- */
function foodList() {
  let list = allFoods();
  if (ui.filter === 'recent') list = S.recent.map(getFood).filter(Boolean);
  if (ui.filter === 'fav') list = list.filter(f => S.favs.includes(f.id));
  if (ui.filter === 'mine') list = S.foods;
  if (ui.q) list = search(ui.q, list);
  if (!list.length) return `<p class="muted center">${ui.q ? 'Нічого не знайдено. Додай свій продукт кнопкою «Продукт».' : 'Тут поки порожньо.'}</p>`;
  return list.slice(0, 80).map(f => `<button class="row" data-a="pick" data-id="${f.id}"><span class="rn">${S.favs.includes(f.id) ? '★ ' : ''}${esc(f.name)}<small>${macro(f)}</small></span><b>${f.kcal}<small> ккал/100 г</small></b></button>`).join('');
}
function renderAdd() {
  const tool = (a, ic, l) => `<button class="tool" data-a="${a}"><span>${ic}</span>${l}</button>`;
  const chip = (v, l) => `<button class="chip${ui.filter === v ? ' on' : ''}" data-a="filter" data-v="${v}">${l}</button>`;
  sheet(`${head('Додати їжу')}${mealSeg()}
    <div class="tools">${tool('openAI', '📷', 'Фото')}${tool('openScan', '▮▯▮', 'Сканер')}${tool('openQuick', '⚡', 'Швидко')}${tool('openFood', '＋', 'Продукт')}${tool('openRecipe', '🍳', 'Рецепт')}</div>
    <input class="inp" type="search" placeholder="Пошук: гречка, борщ, банан…" data-i="search" value="${esc(ui.q)}">
    <div class="chips">${chip('all', 'Усі')}${chip('recent', 'Недавні')}${chip('fav', 'Улюблені')}${chip('mine', 'Мої')}</div>
    <div id="foodlist" class="list">${foodList()}</div>`, { full: true });
}
A.openAdd = el => { ui.meal = el.dataset.meal || mealByTime(); ui.q = ''; ui.filter = S.recent.length ? 'recent' : 'all'; renderAdd(); };
A.backAdd = renderAdd;
A.setMeal = el => { ui.meal = el.dataset.v; el.parentNode.querySelectorAll('button').forEach(b => b.classList.toggle('on', b === el)); const t = $('#addTo'); if (t) t.textContent = mealName(); };
A.filter = el => { ui.filter = el.dataset.v; renderAdd(); };
I.search = el => { ui.q = el.value; if (ui.q && ui.filter !== 'all') { ui.filter = 'all'; document.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.dataset.v === 'all')); } $('#foodlist').innerHTML = foodList(); };

/* ---------- Порція ---------- */
function portionSheet(food) {
  ui.cur = food;
  const g = food.portion || 100, mine = S.foods.includes(food);
  sheet(`${head(food.name, 'backAdd')}
    <p class="muted">${food.kcal} ккал на 100 г · ${macro(food)}${food.recipe ? ' · рецепт' : ''}</p>
    ${mealSeg()}
    <label class="fl">Скільки грамів</label>
    <input class="inp xl" id="gInp" inputmode="decimal" data-i="grams" value="${g}">
    <div class="chips">${[50, 100, 150, 200, 250, 300].map(v => `<button class="chip" data-a="setG" data-v="${v}">${v} г</button>`).join('')}</div>
    <div class="result" id="gRes">${resLine(scale(food, g))}</div>
    <button class="btn primary" data-a="addEntry">Додати в <span id="addTo">${mealName()}</span></button>
    <div class="btnrow"><button class="btn ghost" data-a="fav">${S.favs.includes(food.id) ? '★ В улюблених' : '☆ В улюблені'}</button>
      ${mine ? '<button class="btn ghost" data-a="editFood">Редагувати</button><button class="btn ghost danger" data-a="delFood">Видалити</button>' : ''}</div>`);
}
const resLine = s => `<b>${fmt(s.kcal)} ккал</b><span>Б ${s.p} · Ж ${s.f} · В ${s.c}</span>`;
A.pick = el => portionSheet(getFood(el.dataset.id));
I.grams = el => { $('#gRes').innerHTML = resLine(scale(ui.cur, num(el.value))); };
A.setG = el => { const i = $('#gInp'); i.value = el.dataset.v; I.grams(i); };
A.addEntry = () => {
  const g = num($('#gInp').value), f = ui.cur;
  if (g <= 0) return toast('Введи вагу порції в грамах');
  pushEntry({ name: f.name, g: Math.round(g), ...scale(f, g), foodId: f.id });
  touchRecent(f.id); save(); closeSheet(); app.render(); toast(`Додано: ${f.name}`);
};
A.fav = el => {
  const id = ui.cur.id, on = S.favs.includes(id);
  S.favs = on ? S.favs.filter(x => x !== id) : [id, ...S.favs]; save();
  el.textContent = on ? '☆ В улюблені' : '★ В улюблених';
};
A.delFood = () => {
  const id = ui.cur.id;
  S.foods = S.foods.filter(f => f.id !== id); S.favs = S.favs.filter(x => x !== id); S.recent = S.recent.filter(x => x !== id);
  save(); renderAdd(); toast('Продукт видалено з каталогу');
};

/* ---------- Свій продукт ---------- */
function foodForm(f = {}, barcode = '') {
  ui.editId = f.id || null; ui.newBarcode = barcode || f.barcode || '';
  const fld = (id, l, v, mode = 'decimal') => `<div><label class="fl">${l}</label><input class="inp" id="${id}" inputmode="${mode}" value="${v ?? ''}"></div>`;
  sheet(`${head(f.id ? 'Редагувати продукт' : 'Свій продукт', 'backAdd')}
    ${barcode ? `<p class="muted">Штрихкод ${esc(barcode)} не знайдено в базі. Заповни дані з упаковки — наступного разу сканер його впізнає.</p>` : ''}
    <label class="fl">Назва</label><input class="inp" id="fName" placeholder="Наприклад: Гречка" value="${esc(f.name || '')}">
    <label class="fl">Калорії на 100 г</label><input class="inp xl" id="fKcal" inputmode="decimal" placeholder="105" value="${f.kcal ?? ''}">
    <div class="grid3">${fld('fP', 'Білки, г', f.p)}${fld('fF', 'Жири, г', f.f)}${fld('fC', 'Вуглеводи, г', f.c)}</div>
    <label class="fl">Звична порція, г (необов'язково)</label><input class="inp" id="fPortion" inputmode="numeric" placeholder="100" value="${f.portion ?? ''}">
    <button class="btn primary" data-a="saveFood">Зберегти</button>`);
}
A.openFood = () => foodForm();
A.editFood = () => foodForm(ui.cur);
A.saveFood = () => {
  const name = $('#fName').value.trim(), kcal = num($('#fKcal').value);
  if (!name) return toast('Введи назву продукту');
  if (kcal <= 0 && $('#fKcal').value.trim() === '') return toast('Введи калорії на 100 г');
  const data = { name, kcal: Math.round(kcal), p: r1(num($('#fP').value)), f: r1(num($('#fF').value)), c: r1(num($('#fC').value)), portion: Math.round(num($('#fPortion').value)) || undefined };
  let food = S.foods.find(f => f.id === ui.editId);
  if (food) Object.assign(food, data);
  else { food = { id: 'u' + uid(), ...data }; if (ui.newBarcode) food.barcode = ui.newBarcode; S.foods.unshift(food); }
  save(); portionSheet(food); toast('Збережено в каталог');
};

/* ---------- Швидкий запис ---------- */
A.openQuick = () => sheet(`${head('Швидкий запис', 'backAdd')}
  <p class="muted">Коли знаєш калорії страви й не хочеш шукати її в каталозі.</p>${mealSeg()}
  <label class="fl">Назва</label><input class="inp" id="qName" placeholder="Наприклад: Обід у кафе">
  <label class="fl">Калорії</label><input class="inp xl" id="qKcal" inputmode="decimal" placeholder="450">
  <div class="grid3"><div><label class="fl">Білки, г</label><input class="inp" id="qP" inputmode="decimal"></div><div><label class="fl">Жири, г</label><input class="inp" id="qF" inputmode="decimal"></div><div><label class="fl">Вуглеводи, г</label><input class="inp" id="qC" inputmode="decimal"></div></div>
  <button class="btn primary" data-a="addQuick">Додати в <span id="addTo">${mealName()}</span></button>`);
A.addQuick = () => {
  const kcal = num($('#qKcal').value);
  if (kcal <= 0) return toast('Введи кількість калорій');
  pushEntry({ name: $('#qName').value.trim() || 'Швидкий запис', g: null, kcal: Math.round(kcal), p: r1(num($('#qP').value)), f: r1(num($('#qF').value)), c: r1(num($('#qC').value)) });
  closeSheet(); app.render(); toast('Додано');
};

/* ---------- Редагування запису ---------- */
A.editEntry = el => {
  const e = dayMut(ui.date).entries.find(x => x.id === el.dataset.id);
  if (!e) return;
  ui.entry = e; ui.meal = e.meal;
  sheet(`${head(e.name)}${mealSeg()}
    <label class="fl">${e.g ? 'Скільки грамів' : 'Калорії'}</label>
    <input class="inp xl" id="eVal" inputmode="decimal" value="${e.g || e.kcal}">
    <button class="btn primary" data-a="saveEntry">Зберегти</button>
    <button class="btn ghost danger" data-a="delEntry">Видалити запис</button>`);
};
A.saveEntry = () => {
  const e = ui.entry, v = num($('#eVal').value);
  if (v <= 0) return toast('Значення має бути більше нуля');
  if (e.g) { const k = v / e.g; e.kcal = Math.round(e.kcal * k); e.p = r1((e.p || 0) * k); e.f = r1((e.f || 0) * k); e.c = r1((e.c || 0) * k); e.g = Math.round(v); }
  else e.kcal = Math.round(v);
  e.meal = ui.meal; save(); closeSheet(); app.render();
};
A.delEntry = () => { const d = dayMut(ui.date); d.entries = d.entries.filter(x => x !== ui.entry); save(); closeSheet(); app.render(); toast('Запис видалено'); };

/* ---------- Рецепт ---------- */
const recSum = () => {
  const r = ui.rec, t = r.items.reduce((s, i) => { const x = scale(i.food, i.g); s.g += i.g; s.kcal += x.kcal; s.p += x.p; s.f += x.f; s.c += x.c; return s; }, { g: 0, kcal: 0, p: 0, f: 0, c: 0 });
  const total = num(r.total) || t.g, k = total ? 100 / total : 0;
  return { t, total, per: { kcal: Math.round(t.kcal * k), p: r1(t.p * k), f: r1(t.f * k), c: r1(t.c * k) } };
};
const recItems = () => ui.rec.items.map((i, n) => `<div class="recrow"><span>${esc(i.food.name)}</span><input class="inp sm" inputmode="decimal" data-i="recG" data-n="${n}" value="${i.g}" aria-label="Грами"><small>г</small><button class="ic" data-a="recDel" data-n="${n}" aria-label="Прибрати">✕</button></div>`).join('') || '<p class="muted">Знайди інгредієнти через пошук вище.</p>';
const recInfo = () => { const s = recSum(); return ui.rec.items.length ? `<b>${s.per.kcal} ккал на 100 г</b><span>уся страва: ${fmt(s.t.kcal)} ккал, ${fmt(s.total)} г · Б ${s.per.p} · Ж ${s.per.f} · В ${s.per.c}</span>` : ''; };
A.openRecipe = () => {
  ui.rec = { items: [], total: '' };
  sheet(`${head('Новий рецепт', 'backAdd')}
    <label class="fl">Назва страви</label><input class="inp" id="recName" placeholder="Наприклад: Мій борщ">
    <label class="fl">Інгредієнти</label><input class="inp" type="search" placeholder="Пошук інгредієнта" data-i="recSearch" id="recQ">
    <div id="recRes" class="list"></div><div id="recItems">${recItems()}</div>
    <label class="fl">Вага готової страви, г (якщо відрізняється від суми)</label><input class="inp" inputmode="decimal" data-i="recTotal" placeholder="сума інгредієнтів">
    <div class="result" id="recInfo"></div>
    <button class="btn primary" data-a="saveRecipe">Зберегти рецепт</button>`, { full: true });
};
const recRefresh = () => { $('#recInfo').innerHTML = recInfo(); };
I.recSearch = el => { $('#recRes').innerHTML = el.value.trim() ? search(el.value, allFoods()).slice(0, 6).map(f => `<button class="row" data-a="recAdd" data-id="${f.id}"><span class="rn">${esc(f.name)}</span><b>${f.kcal}<small> ккал/100 г</small></b></button>`).join('') : ''; };
A.recAdd = el => { ui.rec.items.push({ food: getFood(el.dataset.id), g: 100 }); $('#recQ').value = ''; $('#recRes').innerHTML = ''; $('#recItems').innerHTML = recItems(); recRefresh(); };
A.recDel = el => { ui.rec.items.splice(+el.dataset.n, 1); $('#recItems').innerHTML = recItems(); recRefresh(); };
I.recG = el => { ui.rec.items[+el.dataset.n].g = num(el.value); recRefresh(); };
I.recTotal = el => { ui.rec.total = el.value; recRefresh(); };
A.saveRecipe = () => {
  const name = $('#recName').value.trim(), s = recSum();
  if (!name) return toast('Введи назву страви');
  if (!ui.rec.items.length || !s.total) return toast('Додай хоча б один інгредієнт');
  const food = { id: 'u' + uid(), name, ...s.per, recipe: true };
  S.foods.unshift(food); save(); portionSheet(food); toast('Рецепт збережено в каталог');
};

/* ---------- Аналіз фото ---------- */
A.openAI = () => {
  ui.ai = { token: 0 };
  if (!S.settings.geminiKey) return sheet(`${head('Аналіз фото', 'backAdd')}
    <p>Щоб розпізнавати їжу з фото, потрібен безкоштовний ключ Google Gemini. Він вставляється один раз у профілі.</p>
    <button class="btn primary" data-a="goSettings">Відкрити профіль</button>`);
  sheet(`${head('Аналіз фото', 'backAdd')}
    <p class="muted">Сфотографуй тарілку так, щоб було видно всю їжу. Оцінка приблизна — перед збереженням її можна виправити.</p>
    <label class="fl">Уточнення (необов'язково)</label><input class="inp" id="aiHint" placeholder="Наприклад: каша на молоці, порція велика">
    <label class="btn primary">📷 Зробити фото<input type="file" accept="image/*" capture="environment" hidden data-c="aiFile"></label>
    <label class="btn soft">🖼 Вибрати з галереї<input type="file" accept="image/*" hidden data-c="aiFile"></label>`);
};
A.goSettings = () => { closeSheet(); ui.tab = 'profile'; app.render(); scrollTo(0, document.body.scrollHeight); };
C.aiFile = async el => {
  const file = el.files[0];
  if (!file) return;
  const hint = $('#aiHint')?.value.trim() || '', token = ++ui.ai.token;
  try {
    const img = await fileToJpegBase64(file);
    ui.ai.img = img.dataUrl;
    sheet(`${head('Аналіз фото', 'openAI')}<img class="preview" src="${img.dataUrl}" alt="Фото їжі"><div class="loading"><i></i>Розпізнаю їжу…</div>`);
    const items = await analyzePhoto(img.base64, hint);
    if (ui.ai.token !== token) return;
    ui.ai.items = items.map(i => ({ ...i, base: { ...i } }));
    aiResult();
  } catch (e) {
    if (ui.ai.token !== token) return;
    sheet(`${head('Аналіз фото', 'openAI')}<p class="err">${esc(e.message === 'NO_KEY' ? 'Спершу додай ключ Gemini у профілі.' : e.message)}</p><button class="btn soft" data-a="openAI">Спробувати ще раз</button>`);
  }
};
const aiTotal = () => `Разом: <b>${fmt(ui.ai.items.reduce((s, i) => s + i.kcal, 0))} ккал</b>`;
function aiResult() {
  const it = ui.ai.items;
  sheet(`${head('Результат', 'openAI')}<img class="preview sm" src="${ui.ai.img}" alt="Фото їжі">
    ${it.length ? `${mealSeg()}<div id="aiRows">${it.map((i, n) => `<div class="airow">
      <input class="inp" data-i="aiName" data-n="${n}" value="${esc(i.name)}" aria-label="Назва">
      <div class="aiflds"><label><input class="inp sm" inputmode="decimal" data-i="aiG" data-n="${n}" value="${i.g}"><small>г</small></label>
        <label><input class="inp sm" inputmode="decimal" data-i="aiK" data-n="${n}" id="aiK${n}" value="${i.kcal}"><small>ккал</small></label>
        <span class="muted" id="aiM${n}">${macro(i)}</span><button class="ic" data-a="aiDel" data-n="${n}" aria-label="Прибрати">✕</button></div></div>`).join('')}</div>
      <div class="result" id="aiTotal">${aiTotal()}</div>
      <button class="btn primary" data-a="aiAdd">Додати в <span id="addTo">${mealName()}</span></button>
      <p class="muted center">Оцінка з фото приблизна. Змінюєш грами — калорії перераховуються.</p>`
    : '<p>Їжі на фото не знайшов. Спробуй зняти ближче та при кращому світлі.</p><button class="btn soft" data-a="openAI">Інше фото</button>'}`, { full: true });
}
I.aiName = el => { ui.ai.items[+el.dataset.n].name = el.value; };
I.aiG = el => {
  const n = +el.dataset.n, i = ui.ai.items[n], g = num(el.value), k = i.base.g ? g / i.base.g : 1;
  Object.assign(i, { g: Math.round(g), kcal: Math.round(i.base.kcal * k), p: r1(i.base.p * k), f: r1(i.base.f * k), c: r1(i.base.c * k) });
  $('#aiK' + n).value = i.kcal; $('#aiM' + n).textContent = macro(i); $('#aiTotal').innerHTML = aiTotal();
};
I.aiK = el => { ui.ai.items[+el.dataset.n].kcal = Math.round(num(el.value)); $('#aiTotal').innerHTML = aiTotal(); };
A.aiDel = el => { ui.ai.items.splice(+el.dataset.n, 1); aiResult(); };
A.aiAdd = () => {
  const items = ui.ai.items.filter(i => i.name.trim() && i.kcal > 0);
  if (!items.length) return toast('Немає що додавати');
  items.forEach(i => pushEntry({ name: i.name.trim(), g: i.g || null, kcal: i.kcal, p: i.p, f: i.f, c: i.c }));
  closeSheet(); app.render(); toast(`Додано страв: ${items.length}`);
};

/* ---------- Сканер штрихкодів ---------- */
A.openScan = () => {
  sheet(`${head('Сканер штрихкоду', 'backAdd')}
    <div class="scanbox"><video id="scanVideo" playsinline muted></video><div class="scanline"></div></div>
    <p class="muted center" id="scanMsg">Наведи камеру на штрихкод упаковки</p>
    <div class="btnrow"><input class="inp" id="codeInp" inputmode="numeric" placeholder="або введи цифри коду"><button class="btn soft" data-a="codeGo">Знайти</button></div>`, { onClose: stopScan });
  startScan($('#scanVideo'), handleCode).catch(() => { const m = $('#scanMsg'); if (m) m.textContent = 'Камера недоступна. Дозволь доступ до камери або введи код вручну.'; });
};
A.codeGo = () => { const c = $('#codeInp').value.replace(/\D/g, ''); if (c.length < 6) return toast('Введи цифри штрихкоду'); stopScan(); handleCode(c); };
async function handleCode(code) {
  const known = S.foods.find(f => f.barcode === code);
  if (known) return portionSheet(known);
  sheet(`${head('Сканер штрихкоду', 'openScan')}<div class="loading"><i></i>Шукаю продукт ${esc(code)}…</div>`);
  try {
    const p = await lookupBarcode(code);
    if (!p) return foodForm({}, code);
    const food = { id: 'u' + uid(), ...p };
    S.foods.unshift(food); save(); portionSheet(food); toast('Продукт знайдено й додано в каталог');
  } catch (e) {
    toast(navigator.onLine ? e.message : 'Немає інтернету — заповни продукт вручну');
    foodForm({}, code);
  }
}

/* ---------- Активність ---------- */
const actRes = () => { const a = ui.act; return `<b>−${fmt(actKcal(ACTS[a.i][1], lastWeight(), a.min))} ккал</b><span>${ACTS[a.i][0]}, ${a.min} хв</span>`; };
A.openAct = () => {
  ui.act = { i: 0, min: 30 };
  sheet(`${head('Додати активність')}
    <div class="chips wrap">${ACTS.map((a, i) => `<button class="chip${i === 0 ? ' on' : ''}" data-a="actPick" data-n="${i}">${a[0]}</button>`).join('')}</div>
    <label class="fl">Тривалість, хв</label><input class="inp xl" inputmode="numeric" data-i="actMin" value="30">
    <div class="result" id="actRes">${actRes()}</div>
    <button class="btn primary" data-a="actAdd">Додати</button>
    <label class="fl">Або впиши свою</label>
    <div class="btnrow"><input class="inp" id="actName" placeholder="Назва"><input class="inp" id="actK" inputmode="numeric" placeholder="ккал"><button class="btn soft" data-a="actCustom">OK</button></div>`);
};
A.actPick = el => { ui.act.i = +el.dataset.n; el.parentNode.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c === el)); $('#actRes').innerHTML = actRes(); };
I.actMin = el => { ui.act.min = Math.max(0, Math.round(num(el.value))); $('#actRes').innerHTML = actRes(); };
const pushAct = a => { dayMut(ui.date).acts.push({ id: uid(), ...a }); save(); closeSheet(); app.render(); toast('Активність додано'); };
A.actAdd = () => { const a = ui.act; if (a.min <= 0) return toast('Введи тривалість'); pushAct({ name: ACTS[a.i][0], min: a.min, kcal: actKcal(ACTS[a.i][1], lastWeight(), a.min) }); };
A.actCustom = () => { const k = Math.round(num($('#actK').value)); if (k <= 0) return toast('Введи спалені калорії'); pushAct({ name: $('#actName').value.trim() || 'Активність', kcal: k }); };
