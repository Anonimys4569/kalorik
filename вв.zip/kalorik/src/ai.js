import { S, save } from './store.js';
import { lang, t } from './i18n.js';
import { reconcile, r1 } from './calc.js';

const API = 'https://generativelanguage.googleapis.com/v1beta';

// Фото зменшуємо до 1280 px — достатньо для впізнавання, а запит лишається швидким.
export function fileToJpegBase64(file, max = 1280) {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      const dataUrl = c.toDataURL('image/jpeg', 0.88);
      res({ dataUrl, base64: dataUrl.split(',')[1] });
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new Error(t('Не вдалося прочитати фото'))); };
    img.src = url;
  });
}

// Назви моделей у Google змінюються, тому беремо актуальну зі списку, а не зашиту в код.
async function pickModel(key) {
  const r = await fetch(`${API}/models?pageSize=200`, { headers: { 'x-goog-api-key': key } });
  if (!r.ok) throw await apiError(r);
  const list = ((await r.json()).models || [])
    .filter(m => (m.supportedGenerationMethods || []).includes('generateContent'))
    .map(m => m.name.replace('models/', ''))
    .filter(n => n.startsWith('gemini') && !/image|tts|live|audio|embed|robot|computer|aqa/.test(n));
  const ver = n => parseFloat((n.match(/gemini-(\d+(\.\d+)?)/) || [0, 0])[1]);
  const score = n => ver(n) * 100 + (/flash/.test(n) ? 20 : 0) - (/lite/.test(n) ? 10 : 0) - (/preview|exp|latest/.test(n) ? 30 : 0) - (/pro/.test(n) ? 15 : 0);
  list.sort((a, b) => score(b) - score(a));
  if (!list.length) throw new Error(t('Для цього ключа немає доступних моделей Gemini'));
  return list[0];
}

async function apiError(r) {
  let msg = '';
  try { msg = (await r.json()).error?.message || ''; } catch { /* тіло не JSON */ }
  if (r.status === 400 && /API key/i.test(msg)) return new Error(t('Ключ Gemini неправильний. Перевір його в налаштуваннях.'));
  if (r.status === 403) return new Error(t('Ключ Gemini не має доступу. Перевір його в Google AI Studio.'));
  if (r.status === 429) return new Error(t('Вичерпано ліміт запитів Gemini. Спробуй трохи пізніше.'));
  return new Error(t('Помилка Gemini ({0}). {1}', r.status, msg).trim());
}

const num = k => ({ type: 'NUMBER', description: k });
const SCHEMA = {
  type: 'OBJECT',
  properties: {
    items: {
      type: 'ARRAY',
      items: {
        type: 'OBJECT',
        properties: {
          name: { type: 'STRING' }, grams: num('weight of the portion in grams'), kcal: num('kcal of this portion'),
          protein: num('g'), fat: num('g'), carbs: num('g'), fiber: num('g'), sugar: num('g, total sugars'), salt: num('g of salt (sodium x 2.5)'),
          confidence: { type: 'STRING', enum: ['high', 'medium', 'low'] },
        },
        required: ['name', 'grams', 'kcal', 'protein', 'fat', 'carbs', 'fiber', 'sugar', 'salt', 'confidence'],
      },
    },
  },
  required: ['items'],
};
const LANG_NAME = { uk: 'Ukrainian', en: 'English', ru: 'Russian' };

const RULES = () => `
Rules:
- Give each distinct dish or product its own item; split a composite plate into its components (e.g. rice, chicken, salad). Do not merge different foods.
- Estimate each portion's weight in grams from visual cues: plate or bowl size (a standard dinner plate is about 26 cm), cutlery, hands, packaging, and how high the food is piled. Weigh cooked food as served, not raw.
- Include visible oil, sauces, dressings, cheese and drinks. Be realistic about hidden fat in fried or creamy dishes.
- Calories, protein, fat, carbs, fiber, sugar and salt must be for the whole portion (not per 100 g), and kcal should be consistent with 4 kcal/g protein, 9 kcal/g fat and 4 kcal/g carbs.
- Set confidence to "low" if the food is hard to identify or the portion is hard to judge, "medium" if estimated, "high" only when it is clear.
- Names: short, in ${LANG_NAME[lang()]}.
- If there is no food, return an empty list.`;

async function ask(parts, hint) {
  const key = S.settings.geminiKey.trim();
  if (!key) throw new Error('NO_KEY');
  if (!navigator.onLine) throw new Error(t('Немає інтернету. Аналіз працює лише онлайн.'));
  const body = JSON.stringify({
    systemInstruction: { parts: [{ text: 'You are an experienced registered dietitian who estimates nutrition precisely from photos, voice and text. Always answer with JSON that matches the schema.' }] },
    contents: [{ parts: [...parts, ...(hint ? [{ text: `User clarification (trust it over your guess): ${hint}` }] : [])] }],
    generationConfig: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.1 },
  });
  const call = model => fetch(`${API}/models/${model}:generateContent`, {
    method: 'POST', headers: { 'x-goog-api-key': key, 'Content-Type': 'application/json' }, body,
  });
  let model = S.settings.geminiModel || await pickModel(key);
  let r = await call(model);
  if (r.status === 404) { model = await pickModel(key); r = await call(model); } // збережену модель могли вимкнути
  if (!r.ok) throw await apiError(r);
  if (S.settings.geminiModel !== model) { S.settings.geminiModel = model; save(); }
  const data = await r.json();
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
  let items;
  try { items = JSON.parse(text).items; } catch { throw new Error(t('Gemini повернув незрозумілу відповідь. Спробуй ще раз.')); }
  return (items || []).filter(i => i.name).map(i => reconcile({
    name: String(i.name), g: Math.round(+i.grams || 0), kcal: Math.round(+i.kcal || 0),
    p: r1(+i.protein || 0), f: r1(+i.fat || 0), c: r1(+i.carbs || 0), fi: r1(+i.fiber || 0), su: r1(+i.sugar || 0),
    sa: Math.round((+i.salt || 0) * 100) / 100, conf: i.confidence || 'medium',
  }));
}

// images — масив base64 JPEG (до 3 ракурсів однієї страви)
export const analyzePhotos = (images, hint = '') => ask([
  { text: `Identify every food and drink in ${images.length > 1 ? 'these photos (different angles of the same meal)' : 'this photo'} and estimate the nutrition.${RULES()}` },
  ...images.map(data => ({ inline_data: { mime_type: 'image/jpeg', data } })),
], hint);

export const analyzeAudio = (wavBase64, hint = '') => ask([
  { text: `Listen to the recording. The person says what they ate or drank. Extract every food and drink with a realistic portion weight (use the amounts they say; if no amount is said, assume a typical serving) and estimate the nutrition.${RULES()}` },
  { inline_data: { mime_type: 'audio/wav', data: wavBase64 } },
], hint);

export const analyzeText = (text, hint = '') => ask([
  { text: `The person describes what they ate or drank: "${text}". Extract every food and drink with a realistic portion weight (use the amounts they say; otherwise assume a typical serving) and estimate the nutrition.${RULES()}` },
], hint);
