import { S, dkey, parseKey, shift, totals, lastWeight } from './store.js';
import { norm } from './calc.js';

// Медалі рахуються з даних щоденника, тому нічого окремо вести не треба.
export const MEDALS = [
  { id: 'first', icon: '🌱', name: 'Перший запис', desc: 'Додай першу страву в щоденник', k: 'entries', max: 1 },
  { id: 'streak3', icon: '🔥', name: '3 дні поспіль', desc: 'Записуй їжу 3 дні підряд', k: 'best', max: 3 },
  { id: 'streak7', icon: '⚡', name: 'Тиждень поспіль', desc: 'Записуй їжу 7 днів підряд', k: 'best', max: 7 },
  { id: 'streak30', icon: '🏆', name: 'Місяць поспіль', desc: 'Записуй їжу 30 днів підряд', k: 'best', max: 30 },
  { id: 'e100', icon: '📒', name: '100 записів', desc: 'Додай 100 страв у щоденник', k: 'entries', max: 100 },
  { id: 'e500', icon: '📚', name: '500 записів', desc: 'Додай 500 страв у щоденник', k: 'entries', max: 500 },
  { id: 'water7', icon: '💧', name: 'Водяний тиждень', desc: 'Виконай норму води у 7 днях', k: 'waterDays', max: 7 },
  { id: 'norm7', icon: '🎯', name: 'У ціль', desc: 'Вклади калорії в норму (±10 %) у 7 днях', k: 'normDays', max: 7 },
  { id: 'prot5', icon: '💪', name: 'Білкова сила', desc: 'Набери норму білка у 5 днях', k: 'protDays', max: 5 },
  { id: 'fiber5', icon: '🥦', name: 'Клітковина в нормі', desc: 'Набери норму клітковини у 5 днях', k: 'fiberDays', max: 5 },
  { id: 'act10', icon: '🏃', name: 'Рухливий', desc: 'Запиши активність у 10 днях', k: 'actDays', max: 10 },
  { id: 'weigh5', icon: '⚖️', name: 'Ваги під контролем', desc: 'Запиши вагу 5 разів', k: 'weights', max: 5 },
  { id: 'goal', icon: '🥇', name: 'Ціль досягнуто', desc: 'Дійди до цільової ваги', k: 'goal', max: 1 },
  { id: 'cook', icon: '🍳', name: 'Кухар', desc: 'Створи власний рецепт', k: 'recipes', max: 1 },
  { id: 'catalog', icon: '📖', name: 'Свій каталог', desc: 'Додай 10 власних продуктів', k: 'own', max: 10 },
  { id: 'photo', icon: '📷', name: 'Фото-аналітик', desc: 'Додай страву за фото', k: 'photo', max: 1 },
  { id: 'voice', icon: '🎤', name: 'Голосовий запис', desc: 'Додай страву голосом', k: 'voice', max: 1 },
];

export function stats() {
  const n = norm(S.profile), keys = Object.keys(S.days).sort();
  const c = { entries: 0, best: 0, waterDays: 0, normDays: 0, protDays: 0, fiberDays: 0, actDays: 0, photo: 0, voice: 0 };
  const logged = [];
  for (const k of keys) {
    const d = S.days[k], t = totals(k);
    c.entries += d.entries.length;
    for (const e of d.entries) { if (e.src === 'photo') c.photo++; if (e.src === 'voice') c.voice++; }
    if (d.water >= n.water) c.waterDays++;
    if (d.acts.length) c.actDays++;
    if (!d.entries.length) continue;
    logged.push(k);
    if (Math.abs(t.kcal - n.kcal) <= n.kcal * 0.1) c.normDays++;
    if (t.p >= n.p * 0.95) c.protDays++;
    if (t.fi >= n.fi * 0.95) c.fiberDays++;
  }
  let run = 0, prev = null;
  for (const k of logged) { run = prev && shift(prev, 1) === k ? run + 1 : 1; c.best = Math.max(c.best, run); prev = k; }
  c.weights = S.weights.length;
  c.recipes = S.foods.filter(f => f.recipe).length;
  c.own = S.foods.length;
  const gw = S.profile.goalWeight, w0 = S.weights.length ? S.weights[0].kg : null, cur = lastWeight();
  c.goal = gw && w0 != null && S.weights.length > 1 && (w0 > gw ? cur <= gw : w0 < gw ? cur >= gw : false) ? 1 : 0;
  return c;
}

export const progress = () => { const c = stats(); return MEDALS.map(m => ({ ...m, cur: Math.min(m.max, c[m.k]), done: c[m.k] >= m.max, date: S.ach[m.id] })); };

// Повертає медалі, які щойно відкрились. Під час першого запуску на старих даних відкриває мовчки.
export function checkNew() {
  const list = progress(), fresh = [], silent = !S.ach._;
  for (const m of list) if (m.done && !S.ach[m.id]) { S.ach[m.id] = dkey(); if (!silent) fresh.push(m); }
  S.ach._ = 1;
  return { fresh, changed: silent || fresh.length > 0 };
}
