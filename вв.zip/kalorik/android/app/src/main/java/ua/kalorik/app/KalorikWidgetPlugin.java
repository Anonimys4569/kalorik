package ua.kalorik.app;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

// Міст між програмою та віджетом: після кожної зміни щоденника програма просить віджет оновитись.
@CapacitorPlugin(name = "KalorikWidget")
public class KalorikWidgetPlugin extends Plugin {
    @PluginMethod
    public void refresh(PluginCall call) {
        KalorikWidget.updateAll(getContext());
        call.resolve();
    }
}
