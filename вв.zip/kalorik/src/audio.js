// Запис голосу: MediaRecorder → декодування → моно 16 кГц WAV (цей формат Gemini приймає з будь-якого пристрою).
let rec = null, stream = null, chunks = [], stopTimer = null;

export const canRecord = () => !!(navigator.mediaDevices?.getUserMedia && window.MediaRecorder);

export async function startRecord(onAuto) {
  stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  chunks = [];
  rec = new MediaRecorder(stream);
  rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
  rec.start();
  stopTimer = setTimeout(() => onAuto?.(), 45000); // не довше 45 секунд
}
function release() {
  clearTimeout(stopTimer);
  stream?.getTracks().forEach(t => t.stop());
  stream = null;
}
export function cancelRecord() { try { if (rec && rec.state !== 'inactive') rec.stop(); } catch { /* вже зупинено */ } release(); rec = null; chunks = []; }

export function stopRecord() {
  return new Promise((res, rej) => {
    if (!rec) return rej(new Error('NO_REC'));
    const r = rec, type = r.mimeType || 'audio/webm';
    r.onstop = async () => {
      release(); rec = null;
      try { res(await toWav(new Blob(chunks, { type }))); } catch (e) { rej(e); }
    };
    if (r.state !== 'inactive') r.stop(); else r.onstop();
  });
}

async function toWav(blob) {
  const AC = window.AudioContext || window.webkitAudioContext, ctx = new AC();
  const ab = await blob.arrayBuffer();
  const buf = await new Promise((res, rej) => { const p = ctx.decodeAudioData(ab, res, rej); if (p?.then) p.then(res, rej); }).catch(() => null);
  ctx.close?.();
  if (!buf) throw new Error('DECODE');
  const rate = 16000, len = Math.max(1, Math.ceil(buf.duration * rate));
  const off = new OfflineAudioContext(1, len, rate), src = off.createBufferSource();
  src.buffer = buf; src.connect(off.destination); src.start();
  const pcm = (await off.startRendering()).getChannelData(0);
  const out = new DataView(new ArrayBuffer(44 + pcm.length * 2));
  const w = (o, s) => [...s].forEach((c, i) => out.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); out.setUint32(4, 36 + pcm.length * 2, true); w(8, 'WAVEfmt '); out.setUint32(16, 16, true); out.setUint16(20, 1, true);
  out.setUint16(22, 1, true); out.setUint32(24, rate, true); out.setUint32(28, rate * 2, true); out.setUint16(32, 2, true); out.setUint16(34, 16, true);
  w(36, 'data'); out.setUint32(40, pcm.length * 2, true);
  for (let i = 0; i < pcm.length; i++) out.setInt16(44 + i * 2, Math.max(-1, Math.min(1, pcm[i])) * 0x7fff, true);
  let bin = ''; const u = new Uint8Array(out.buffer);
  for (let i = 0; i < u.length; i += 0x8000) bin += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return { base64: btoa(bin), seconds: buf.duration };
}
