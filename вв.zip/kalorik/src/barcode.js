import { BrowserMultiFormatReader } from '@zxing/browser';
import { t } from './i18n.js';
import { BarcodeFormat, DecodeHintType } from '@zxing/library';

let controls = null;

export async function startScan(video, onCode) {
  const hints = new Map();
  hints.set(DecodeHintType.POSSIBLE_FORMATS, [BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E]);
  const reader = new BrowserMultiFormatReader(hints);
  let done = false;
  controls = await reader.decodeFromConstraints(
    { audio: false, video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 } } }, video,
    result => { if (result && !done) { done = true; stopScan(); onCode(result.getText()); } });
}
export function stopScan() {
  try { controls?.stop(); } catch { /* камера вже зупинена */ }
  controls = null;
}

// Open Food Facts — відкрита база продуктів, окремий сервер не потрібен.
export async function lookupBarcode(code) {
  const r = await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?fields=product_name,product_name_uk,brands,nutriments,serving_quantity`);
  if (!r.ok && r.status !== 404) throw new Error(t('База продуктів зараз недоступна'));
  const j = await r.json().catch(() => ({}));
  const p = j.product;
  if (!p) return null;
  const n = p.nutriments || {};
  let kcal = n['energy-kcal_100g'];
  if (kcal == null && n['energy_100g'] != null) kcal = n['energy_100g'] / 4.184;
  if (kcal == null) return null;
  const title = (p.product_name_uk || p.product_name || '').trim();
  const name = [title, (p.brands || '').split(',')[0].trim()].filter(Boolean).join(' · ') || t('Продукт {0}', code);
  const r1 = x => Math.round((+x || 0) * 10) / 10;
  return { name, kcal: Math.round(kcal), p: r1(n.proteins_100g), f: r1(n.fat_100g), c: r1(n.carbohydrates_100g),
    fi: r1(n.fiber_100g), su: r1(n.sugars_100g), sa: Math.round((+n.salt_100g || 0) * 100) / 100,
    portion: +p.serving_quantity > 0 ? Math.round(+p.serving_quantity) : undefined, barcode: code };
}
