// Розрахунок денної норми: формула Міффліна — Сан-Жеора × коефіцієнт активності.
export const ACTIVITY = [
  { id: 'sed', k: 1.2, name: 'Сидячий', hint: 'офіс, майже без руху' },
  { id: 'light', k: 1.375, name: 'Легка активність', hint: 'тренування 1–3 рази на тиждень' },
  { id: 'mid', k: 1.55, name: 'Середня активність', hint: 'тренування 3–5 разів на тиждень' },
  { id: 'high', k: 1.725, name: 'Висока активність', hint: 'тренування 6–7 разів на тиждень' },
  { id: 'max', k: 1.9, name: 'Дуже висока', hint: 'фізична робота або спорт щодня' },
];
export const GOALS = [
  { id: 'lose', name: 'Схуднення', delta: -0.15, protein: 2.0 },
  { id: 'keep', name: 'Підтримка ваги', delta: 0, protein: 1.6 },
  { id: 'gain', name: 'Набір ваги', delta: 0.15, protein: 1.8 },
];

export function bmr(p) {
  const base = 10 * p.weight + 6.25 * p.height - 5 * p.age;
  return p.sex === 'f' ? base - 161 : base + 5;
}

export function norm(p) {
  if (p.manual) return { ...p.manual, water: waterNorm(p), auto: false };
  const act = ACTIVITY.find(a => a.id === p.activity) || ACTIVITY[1];
  const goal = GOALS.find(g => g.id === p.goal) || GOALS[1];
  const tdee = bmr(p) * act.k;
  const floor = p.sex === 'f' ? 1200 : 1500; // нижче не опускаємо — це небезпечно для здоров'я
  const kcal = Math.max(floor, Math.round(tdee * (1 + goal.delta) / 10) * 10);
  const prot = Math.round(goal.protein * p.weight);
  const fat = Math.round(kcal * 0.27 / 9);
  const carb = Math.max(0, Math.round((kcal - prot * 4 - fat * 9) / 4));
  return { kcal, p: prot, f: fat, c: carb, water: waterNorm(p), auto: true, bmr: Math.round(bmr(p)), tdee: Math.round(tdee) };
}

export const waterNorm = p => Math.round(p.weight * 30 / 50) * 50; // мл, 30 мл на кг

// Активності: MET × вага (кг) × години = ккал
export const ACTS = [
  ['Ходьба', 3.5], ['Швидка ходьба', 4.5], ['Біг', 9.0], ['Велосипед', 7.0], ['Силове тренування', 5.0],
  ['Плавання', 7.0], ['Футбол', 7.5], ['Баскетбол', 6.5], ['Йога / розтяжка', 2.8], ['Танці', 5.0],
  ['Прибирання', 3.3], ['Скакалка', 10.0], ['Домашнє тренування', 4.5], ['Робота на городі', 4.0],
];
export const actKcal = (met, kg, min) => Math.round(met * kg * min / 60);

export const r1 = x => Math.round(x * 10) / 10;
export function scale(food, g) {
  const k = g / 100;
  return { kcal: Math.round(food.kcal * k), p: r1((food.p || 0) * k), f: r1((food.f || 0) * k), c: r1((food.c || 0) * k) };
}
