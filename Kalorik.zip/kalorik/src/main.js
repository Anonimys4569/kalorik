import './sheets.js';
import { S, load, save, dkey, parseKey, shift, day, dayMut, totals, streak, setWeight, lastWeight } from './store.js';
import { norm, ACTIVITY, GOALS } from './calc.js';
import { barChart, lineChart, ring } from './charts.js';
import { applyReminders, canNotify } from './notify.js';
import { ui, A, C, app, $, esc, num, fmt, MEALS, dateLabel, shortDate, toast } from './ui.js';

function applyTheme() {
  const t = S.settings.theme;
  const dark = t === 'auto' ? matchMedia('(prefers-color-scheme: dark)').matches : t === 'dark';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

/* ---------- Підказка встановлення на iPhone (лише у веб-версії в браузері) ---------- */
const isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const standalone = navigator.standalone === true || matchMedia('(display-mode: standalone)').matches;
const SHARE = '<svg class="shr" viewBox="0 0 24 24" aria-label="Поділитися"><path d="M12 3v12M8 7l4-4 4 4M6 11H5v9h14v-9h-1" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function installHint() {
  if (canNotify() || !isIOS || standalone || S.settings.hideInstall) return '';
  return `<section class="card install"><button class="ic" data-a="hideInstall" aria-label="Сховати підказку">✕</button>
    <b>Встанови Калорік на робочий стіл</b>
    <ol><li>Натисни «Поділитися» ${SHARE} внизу Safari.</li><li>Вибери «На початковий екран».</li><li>Натисни «Додати» і запускай Калорік з іконки.</li></ol>
    <small>Зроби це до заповнення даних: записи з вкладки Safari в ярлик не переносяться.</small></section>`;
}
A.hideInstall = () => { S.settings.hideInstall = true; save(); app.render(); };

/* ---------- Форма профілю (онбординг і вкладка «Профіль») ---------- */
function profileForm() {
  const p = S.profile;
  const seg = (field, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${p[field] === v ? 'on' : ''}" data-a="setP" data-f="${field}" data-v="${v}">${l}</button>`).join('')}</div>`;
  return `
    <label class="fl">Стать</label>${seg('sex', [['m', 'Чоловік'], ['f', 'Жінка']])}
    <div class="grid3">
      <div><label class="fl">Вік</label><input class="inp" inputmode="numeric" data-c="pnum" data-f="age" value="${p.age}"></div>
      <div><label class="fl">Зріст, см</label><input class="inp" inputmode="numeric" data-c="pnum" data-f="height" value="${p.height}"></div>
      <div><label class="fl">Вага, кг</label><input class="inp" inputmode="decimal" data-c="pnum" data-f="weight" value="${p.weight}"></div>
    </div>
    <label class="fl">Активність</label>
    <select class="inp" data-c="psel" data-f="activity">${ACTIVITY.map(a => `<option value="${a.id}" ${p.activity === a.id ? 'selected' : ''}>${a.name} — ${a.hint}</option>`).join('')}</select>
    <label class="fl">Ціль</label>${seg('goal', GOALS.map(g => [g.id, g.name]))}`;
}
A.setP = el => { S.profile[el.dataset.f] = el.dataset.v; save(); app.render(); };
// Після введення оновлюємо лише картку норми: повний перерендер «з'їдав» би наступний дотик по кнопці.
const refreshNorm = () => document.querySelectorAll('.normcard').forEach(el => { el.outerHTML = normCard(); });
C.psel = el => { S.profile[el.dataset.f] = el.value; save(); refreshNorm(); };
C.pnum = el => {
  const f = el.dataset.f, lim = { age: [10, 100], height: [100, 230], weight: [30, 300] }[f];
  const v = Math.min(lim[1], Math.max(lim[0], num(el.value) || S.profile[f]));
  if (f === 'weight') setWeight(dkey(), Math.round(v * 10) / 10); else S.profile[f] = Math.round(v);
  el.value = S.profile[f]; save(); refreshNorm();
};

function normCard() {
  const n = norm(S.profile);
  return `<div class="card normcard">
    <div class="big">${fmt(n.kcal)} <small>ккал на день</small></div>
    <div class="macrorow"><span class="pill p">Білки ${n.p} г</span><span class="pill f">Жири ${n.f} г</span><span class="pill c">Вуглеводи ${n.c} г</span></div>
    <div class="muted">Вода: ${fmt(n.water)} мл${n.auto ? ` · базовий обмін ${fmt(n.bmr)} ккал · витрата за день ${fmt(n.tdee)} ккал` : ' · норму задано вручну'}</div>
  </div>`;
}

function onboarding() {
  return `<div class="onb">
    <div class="logo">Калорік</div>
    ${installHint()}
    <p class="lead">Розкажи про себе — порахую твою денну норму калорій, білків, жирів і вуглеводів.</p>
    <div class="card">${profileForm()}</div>
    ${normCard()}
    <button class="btn primary" data-a="start">Почати</button>
  </div>`;
}
A.start = () => { S.onboarded = true; setWeight(dkey(), S.profile.weight); save(); app.render(); };

/* ---------- Щоденник ---------- */
function diary() {
  const k = ui.date, d = day(k), t = totals(k), n = norm(S.profile);
  const left = n.kcal + t.burned - t.kcal, over = left < 0;
  const today = k === dkey();
  const bar = (cls, name, v, max) => `<div class="mbar"><div class="mhead"><span>${name}</span><b>${Math.round(v)}<small> / ${max} г</small></b></div><div class="track"><div class="fill ${cls}" style="width:${Math.min(100, max ? v / max * 100 : 0)}%"></div></div></div>`;
  const st = streak();
  const glasses = Math.round(d.water / 250), gl = Math.max(Math.ceil(n.water / 250), glasses);
  return `
  <header class="top">
    <button class="ic" data-a="day" data-n="-1" aria-label="Попередній день">‹</button>
    <button class="datebtn" data-a="today"><b>${today ? 'Сьогодні' : k === shift(dkey(), -1) ? 'Учора' : dateLabel(parseKey(k))}</b>${today || k === shift(dkey(), -1) ? `<small>${dateLabel(parseKey(k))}</small>` : '<small>натисни, щоб повернутись до сьогодні</small>'}</button>
    <button class="ic" data-a="day" data-n="1" aria-label="Наступний день" ${today ? 'disabled' : ''}>›</button>
  </header>
  ${installHint()}
  <section class="card hero">
    <div class="ringwrap">${ring(n.kcal + t.burned ? t.kcal / (n.kcal + t.burned) : 0, over)}
      <div class="ringtxt"><b class="${over ? 'bad' : ''}">${fmt(Math.abs(left))}</b><span>${over ? 'ккал понад норму' : 'ккал залишилось'}</span></div></div>
    <div class="herostats">
      <div><span>З'їдено</span><b>${fmt(t.kcal)}</b></div>
      <div><span>Спалено</span><b>${fmt(t.burned)}</b></div>
      <div><span>Норма</span><b>${fmt(n.kcal)}</b></div>
      ${st ? `<div class="streak">🔥 ${st} ${plural(st, 'день', 'дні', 'днів')} поспіль</div>` : ''}
    </div>
  </section>
  <section class="card macros">${bar('p', 'Білки', t.p, n.p)}${bar('f', 'Жири', t.f, n.f)}${bar('c', 'Вуглеводи', t.c, n.c)}</section>
  ${MEALS.map(m => {
    const es = d.entries.filter(e => e.meal === m.id), sum = es.reduce((s, e) => s + e.kcal, 0);
    return `<section class="card meal">
      <div class="mealhead"><span class="micon">${m.icon}</span><b>${m.name}</b><span class="mk">${sum ? fmt(sum) + ' ккал' : ''}</span>
        <button class="addbtn" data-a="openAdd" data-meal="${m.id}" aria-label="Додати в ${m.name}">+</button></div>
      ${es.map(e => `<button class="row" data-a="editEntry" data-id="${e.id}"><span class="rn">${esc(e.name)}<small>${e.g ? e.g + ' г · ' : ''}Б ${Math.round(e.p || 0)} · Ж ${Math.round(e.f || 0)} · В ${Math.round(e.c || 0)}</small></span><b>${fmt(e.kcal)}</b></button>`).join('')}
    </section>`;
  }).join('')}
  <section class="card">
    <div class="mealhead"><span class="micon">💧</span><b>Вода</b><span class="mk">${fmt(d.water)} / ${fmt(n.water)} мл</span></div>
    <div class="glasses">${Array.from({ length: gl }, (_, i) => `<i class="${i < glasses ? 'on' : ''}"></i>`).join('')}</div>
    <div class="btnrow"><button class="btn ghost" data-a="water" data-n="-250" ${d.water ? '' : 'disabled'}>− 250 мл</button><button class="btn soft" data-a="water" data-n="250">+ 250 мл</button></div>
  </section>
  <section class="card meal">
    <div class="mealhead"><span class="micon">🏃</span><b>Активність</b><span class="mk">${t.burned ? '−' + fmt(t.burned) + ' ккал' : ''}</span>
      <button class="addbtn" data-a="openAct" aria-label="Додати активність">+</button></div>
    ${d.acts.map(a => `<button class="row" data-a="delAct" data-id="${a.id}"><span class="rn">${esc(a.name)}<small>${a.min ? a.min + ' хв · ' : ''}натисни, щоб видалити</small></span><b>−${fmt(a.kcal)}</b></button>`).join('')}
  </section>`;
}
export const plural = (n, a, b, c) => { const m = n % 10, h = n % 100; return m === 1 && h !== 11 ? a : m >= 2 && m <= 4 && (h < 12 || h > 14) ? b : c; };
A.day = el => { const k = shift(ui.date, +el.dataset.n); if (k <= dkey()) { ui.date = k; app.render(); scrollTo(0, 0); } };
A.today = () => { ui.date = dkey(); app.render(); };
A.water = el => { const d = dayMut(ui.date); d.water = Math.max(0, d.water + +el.dataset.n); save(); app.render(); };
A.delAct = el => { const d = dayMut(ui.date); d.acts = d.acts.filter(a => a.id !== el.dataset.id); save(); app.render(); toast('Активність видалено'); };

/* ---------- Статистика ---------- */
function stats() {
  const n = norm(S.profile), keys = Array.from({ length: ui.range }, (_, i) => shift(dkey(), i - ui.range + 1));
  const ts = keys.map(k => totals(k)), logged = ts.filter(t => t.kcal > 0);
  const avg = f => logged.length ? logged.reduce((s, t) => s + t[f], 0) / logged.length : 0;
  const water = keys.map(k => day(k).water).filter(Boolean);
  const pts = keys.map((k, i) => ({ label: ui.range === 7 ? dateLabel(parseKey(k)).slice(0, 2) : shortDate(parseKey(k)), v: ts[i].kcal }));
  const row = (cls, name, v, max) => `<div class="mbar"><div class="mhead"><span>${name}</span><b>${Math.round(v)}<small> / ${max} г</small></b></div><div class="track"><div class="fill ${cls}" style="width:${Math.min(100, max ? v / max * 100 : 0)}%"></div></div></div>`;
  return `
  <header class="top plain"><h1>Статистика</h1></header>
  <div class="seg wide"><button class="${ui.range === 7 ? 'on' : ''}" data-a="range" data-n="7">Тиждень</button><button class="${ui.range === 30 ? 'on' : ''}" data-a="range" data-n="30">Місяць</button></div>
  <section class="card"><h3>Калорії по днях</h3>${barChart(pts, n.kcal)}
    <div class="legend"><span><i class="lg bar"></i>з'їдено</span><span><i class="lg over"></i>понад норму</span><span><i class="lg dash"></i>норма ${fmt(n.kcal)}</span></div></section>
  <div class="tiles">
    <div class="tile"><span>У середньому</span><b>${fmt(avg('kcal'))}</b><small>ккал на день</small></div>
    <div class="tile"><span>Днів із записами</span><b>${logged.length}</b><small>із ${ui.range}</small></div>
    <div class="tile"><span>Серія</span><b>${streak()}</b><small>днів поспіль</small></div>
    <div class="tile"><span>Вода</span><b>${water.length ? fmt(water.reduce((a, b) => a + b, 0) / water.length) : 0}</b><small>мл на день</small></div>
  </div>
  <section class="card macros"><h3>БЖВ у середньому за день</h3>${row('p', 'Білки', avg('p'), n.p)}${row('f', 'Жири', avg('f'), n.f)}${row('c', 'Вуглеводи', avg('c'), n.c)}</section>`;
}
A.range = el => { ui.range = +el.dataset.n; app.render(); };

/* ---------- Вага ---------- */
function weight() {
  const w = S.weights, cur = lastWeight(), first = w.length ? w[0].kg : cur, diff = cur - first;
  const bmi = cur / ((S.profile.height / 100) ** 2);
  const pts = w.slice(-60).map(x => ({ label: shortDate(parseKey(x.d)), v: x.kg }));
  return `
  <header class="top plain"><h1>Вага</h1></header>
  <div class="tiles">
    <div class="tile"><span>Зараз</span><b>${cur}</b><small>кг</small></div>
    <div class="tile"><span>Зміна</span><b>${diff > 0 ? '+' : ''}${diff.toFixed(1)}</b><small>кг від початку</small></div>
    <div class="tile"><span>ІМТ</span><b>${bmi.toFixed(1)}</b><small>індекс маси тіла</small></div>
  </div>
  <section class="card"><h3>Записати вагу сьогодні</h3>
    <div class="btnrow"><input class="inp" id="wInp" inputmode="decimal" placeholder="${cur}" aria-label="Вага в кілограмах"><button class="btn soft" data-a="addWeight">Зберегти</button></div></section>
  <section class="card"><h3>Графік</h3>${pts.length >= 2 ? lineChart(pts) : '<p class="muted">Запиши вагу хоча б у два різні дні — тут з\'явиться графік.</p>'}</section>
  <section class="card meal"><h3>Історія</h3>${w.slice(-15).reverse().map(x => `<button class="row" data-a="delWeight" data-d="${x.d}"><span class="rn">${dateLabel(parseKey(x.d))}<small>натисни, щоб видалити</small></span><b>${x.kg} кг</b></button>`).join('') || '<p class="muted">Записів ще немає.</p>'}</section>`;
}
A.addWeight = () => {
  const v = num($('#wInp').value);
  if (v < 30 || v > 300) return toast('Введи вагу від 30 до 300 кг');
  setWeight(dkey(), Math.round(v * 10) / 10); save(); app.render(); toast('Вагу збережено, норму перераховано');
};
A.delWeight = el => {
  S.weights = S.weights.filter(x => x.d !== el.dataset.d);
  if (S.weights.length) S.profile.weight = S.weights[S.weights.length - 1].kg;
  save(); app.render();
};

/* ---------- Профіль і налаштування ---------- */
function profile() {
  const s = S.settings, r = s.reminders, m = S.profile.manual, n = norm(S.profile);
  const sw = (key, on) => `<button class="sw${on ? ' on' : ''}" data-a="toggle" data-k="${key}" role="switch" aria-checked="${on}"><i></i></button>`;
  return `
  <header class="top plain"><h1>Профіль</h1></header>
  ${normCard()}
  <section class="card"><h3>Мої дані</h3>${profileForm()}</section>
  <section class="card"><div class="line"><div><b>Задати норму вручну</b><small>замість автоматичного розрахунку</small></div>${sw('manual', !!m)}</div>
    ${m ? `<div class="grid4">${[['kcal', 'ккал'], ['p', 'Білки'], ['f', 'Жири'], ['c', 'Вугл.']].map(([f, l]) => `<div><label class="fl">${l}</label><input class="inp" inputmode="numeric" data-c="manual" data-f="${f}" value="${n[f]}"></div>`).join('')}</div>` : ''}</section>
  <section class="card"><h3>Тема</h3><div class="seg">${[['dark', 'Темна'], ['light', 'Світла'], ['auto', 'Як у системі']].map(([v, l]) => `<button class="${s.theme === v ? 'on' : ''}" data-a="theme" data-v="${v}">${l}</button>`).join('')}</div></section>
  <section class="card"><h3>Нагадування</h3>
    ${canNotify() ? '' : '<p class="muted">Нагадування працюють у встановленій програмі на телефоні.</p>'}
    <div class="line"><div><b>Записати їжу</b><small>сніданок, обід, вечеря</small></div>${sw('meals', r.meals)}</div>
    ${r.meals ? `<div class="grid3">${r.times.map((t, i) => `<input class="inp" type="time" data-c="rtime" data-n="${i}" value="${t}" aria-label="Час нагадування ${i + 1}">`).join('')}</div>` : ''}
    <div class="line"><div><b>Випити води</b><small>з ${r.waterFrom}:00 до ${r.waterTo}:00</small></div>${sw('water', r.water)}</div>
    ${r.water ? `<label class="fl">Як часто</label><div class="seg">${[1, 2, 3].map(h => `<button class="${r.waterEvery === h ? 'on' : ''}" data-a="wevery" data-n="${h}">кожні ${h} год</button>`).join('')}</div>` : ''}
  </section>
  <section class="card"><h3>Аналіз їжі з фото</h3>
    <p class="muted">Фото розпізнає Google Gemini. Створи безкоштовний ключ на aistudio.google.com/apikey і встав його сюди. Ключ зберігається лише на цьому телефоні.</p>
    <input class="inp" type="password" autocomplete="off" placeholder="Ключ Gemini API" data-c="gkey" value="${esc(s.geminiKey)}">
    ${s.geminiModel ? `<p class="muted">Модель: ${esc(s.geminiModel)}</p>` : ''}</section>
  <p class="muted center">Калорік 1.0 · усі дані зберігаються на цьому пристрої</p>`;
}
A.theme = el => { S.settings.theme = el.dataset.v; save(); applyTheme(); app.render(); };
A.toggle = async el => {
  const k = el.dataset.k, r = S.settings.reminders;
  if (k === 'manual') { const n = norm(S.profile); S.profile.manual = S.profile.manual ? null : { kcal: n.kcal, p: n.p, f: n.f, c: n.c }; }
  else {
    r[k] = !r[k];
    if (canNotify()) { const ok = await applyReminders().catch(() => false); if (!ok && r[k]) { r[k] = false; toast('Дозволь сповіщення в налаштуваннях телефону'); } }
  }
  save(); app.render();
};
C.manual = el => { S.profile.manual[el.dataset.f] = Math.max(0, Math.round(num(el.value))); save(); refreshNorm(); };
C.rtime = el => { if (el.value) { S.settings.reminders.times[+el.dataset.n] = el.value; save(); applyReminders().catch(() => {}); } };
A.wevery = el => { S.settings.reminders.waterEvery = +el.dataset.n; save(); applyReminders().catch(() => {}); app.render(); };
C.gkey = el => { S.settings.geminiKey = el.value.trim(); S.settings.geminiModel = ''; save(); toast(el.value.trim() ? 'Ключ збережено' : 'Ключ видалено'); };

/* ---------- Каркас ---------- */
const TABS = [['diary', 'Щоденник', '📖'], ['stats', 'Статистика', '📊'], ['weight', 'Вага', '⚖️'], ['profile', 'Профіль', '👤']];
const SCREENS = { diary, stats, weight, profile };
app.render = () => {
  const root = $('#app');
  if (!S.onboarded) { root.innerHTML = onboarding(); return; }
  const y = scrollY;
  const tab = (t) => `<button class="tab${ui.tab === t[0] ? ' on' : ''}" data-a="tab" data-t="${t[0]}"><span>${t[2]}</span>${t[1]}</button>`;
  root.innerHTML = `<main>${SCREENS[ui.tab]()}</main>
    <nav class="tabbar">${tab(TABS[0])}${tab(TABS[1])}<button class="fab" data-a="openAdd" aria-label="Додати їжу">+</button>${tab(TABS[2])}${tab(TABS[3])}</nav>`;
  scrollTo(0, y);
};
A.tab = el => { if (ui.tab !== el.dataset.t) { ui.tab = el.dataset.t; app.render(); scrollTo(0, 0); } };

// Веб-версія (для iPhone): кешуємо файли, щоб програма відкривалась без інтернету.
if (!canNotify() && 'serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('./sw.js').catch(() => {});

load().then(() => { applyTheme(); app.render(); if (canNotify()) applyReminders().catch(() => {}); });
