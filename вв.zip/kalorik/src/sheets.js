import { S, save, uid, dayMut, touchRecent, lastWeight } from './store.js';
import { BASE_FOODS } from './foods.js';
import { scale, ACTS, actKcal, r1 } from './calc.js';
import { analyzePhotos, analyzeAudio, analyzeText, fileToJpegBase64 } from './ai.js';
import { canRecord, startRecord, stopRecord, cancelRecord } from './audio.js';
import { startScan, stopScan, lookupBarcode } from './barcode.js';
import { t, fname, fmt, fmt1 } from './i18n.js';
import { ui, A, I, C, app, $, esc, num, MEALS, sheet, closeSheet, toast } from './ui.js';

const allFoods = () => [...S.foods, ...BASE_FOODS];
const getFood = id => allFoods().find(f => f.id === id);
const mealName = () => MEALS.find(m => m.id === ui.meal).name;
const mealByTime = () => { const h = new Date().getHours(); return h < 11 ? 'breakfast' : h < 16 ? 'lunch' : h < 21 ? 'dinner' : 'snack'; };
const head = (title, back) => `<div class="sh-head">${back ? `<button class="ic" data-a="${back}" aria-label="${t('Назад')}">‹</button>` : ''}<h2>${esc(title)}</h2><button class="ic" data-a="closeSheet" aria-label="${t('Закрити')}">✕</button></div>`;
const mealSeg = () => `<div class="seg">${MEALS.map(m => `<button class="${ui.meal === m.id ? 'on' : ''}" data-a="setMeal" data-v="${m.id}">${m.name}</button>`).join('')}</div>`;
const names = f => [fname(f), f.name, ...Object.values(f.tr || {})].join(' ').toLowerCase();
const search = (q, list) => { const ws = q.toLowerCase().split(/\s+/).filter(Boolean); return list.filter(f => { const n = names(f); return ws.every(w => n.includes(w)); }); };
const macro = f => `${t('Б')} ${fmt1(f.p || 0)} · ${t('Ж')} ${fmt1(f.f || 0)} · ${t('В')} ${fmt1(f.c || 0)}`;
const micro = f => `${t('Клітковина')} ${fmt1(f.fi || 0)} ${t('г')} · ${t('Цукор')} ${fmt1(f.su || 0)} ${t('г')} · ${t('Сіль')} ${fmt1(f.sa || 0)} ${t('г')}`;
function pushEntry(e) { dayMut(ui.date).entries.push({ id: uid(), meal: ui.meal, ...e }); save(); }

/* ---------- Додати їжу ---------- */
function foodList() {
  let list = allFoods();
  if (ui.filter === 'recent') list = S.recent.map(getFood).filter(Boolean);
  if (ui.filter === 'fav') list = list.filter(f => S.favs.includes(f.id));
  if (ui.filter === 'mine') list = S.foods;
  if (ui.q) list = search(ui.q, list);
  if (!list.length) return `<p class="muted center">${ui.q ? t('Нічого не знайдено. Додай свій продукт кнопкою «Продукт».') : t('Тут поки порожньо.')}</p>`;
  return list.slice(0, 80).map(f => `<button class="row" data-a="pick" data-id="${f.id}"><span class="rn">${S.favs.includes(f.id) ? '★ ' : ''}${esc(fname(f))}<small>${macro(f)}</small></span><b>${f.kcal}<small> ${t('ккал/100 г')}</small></b></button>`).join('');
}
function renderAdd() {
  const tool = (a, ic, l) => `<button class="tool" data-a="${a}"><span>${ic}</span>${l}</button>`;
  const chip = (v, l) => `<button class="chip${ui.filter === v ? ' on' : ''}" data-a="filter" data-v="${v}">${l}</button>`;
  sheet(`${head(t('Додати їжу'))}${mealSeg()}
    <div class="tools">${tool('openAI', '📷', t('Фото'))}${tool('openVoice', '🎤', t('Голос'))}${tool('openScan', '▮▯▮', t('Сканер'))}${tool('openQuick', '⚡', t('Швидко'))}${tool('openFood', '＋', t('Продукт'))}${tool('openRecipe', '🍳', t('Рецепт'))}</div>
    <input class="inp" type="search" placeholder="${t('Пошук: гречка, борщ, банан…')}" data-i="search" value="${esc(ui.q)}">
    <div class="chips">${chip('all', t('Усі'))}${chip('recent', t('Недавні'))}${chip('fav', t('Улюблені'))}${chip('mine', t('Мої'))}</div>
    <div id="foodlist" class="list">${foodList()}</div>`, { full: true });
}
A.openAdd = el => { ui.meal = el.dataset.meal || mealByTime(); ui.q = ''; ui.filter = S.recent.length ? 'recent' : 'all'; renderAdd(); };
A.backAdd = renderAdd;
A.setMeal = el => { ui.meal = el.dataset.v; el.parentNode.querySelectorAll('button').forEach(b => b.classList.toggle('on', b === el)); const x = $('#addTo'); if (x) x.textContent = mealName(); };
A.filter = el => { ui.filter = el.dataset.v; renderAdd(); };
I.search = el => { ui.q = el.value; if (ui.q && ui.filter !== 'all') { ui.filter = 'all'; document.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.dataset.v === 'all')); } $('#foodlist').innerHTML = foodList(); };

/* ---------- Порція ---------- */
function portionSheet(food) {
  ui.cur = food;
  const g = food.portion || 100, mine = S.foods.includes(food);
  sheet(`${head(fname(food), 'backAdd')}
    <p class="muted">${food.kcal} ${t('ккал на 100 г')} · ${macro(food)}${food.recipe ? ' · ' + t('рецепт') : ''}<br>${micro(food)}</p>
    ${mealSeg()}
    <label class="fl">${t('Скільки грамів')}</label>
    <input class="inp xl" id="gInp" inputmode="decimal" data-i="grams" value="${g}">
    <div class="chips">${[50, 100, 150, 200, 250, 300].map(v => `<button class="chip" data-a="setG" data-v="${v}">${v} ${t('г')}</button>`).join('')}</div>
    <div class="result" id="gRes">${resLine(scale(food, g))}</div>
    <button class="btn primary" data-a="addEntry">${t('Додати в')} <span id="addTo">${mealName()}</span></button>
    <div class="btnrow"><button class="btn ghost" data-a="fav">${S.favs.includes(food.id) ? t('★ В улюблених') : t('☆ В улюблені')}</button>
      ${mine ? `<button class="btn ghost" data-a="editFood">${t('Редагувати')}</button><button class="btn ghost danger" data-a="delFood">${t('Видалити')}</button>` : ''}</div>`);
}
const resLine = s => `<b>${fmt(s.kcal)} ${t('ккал')}</b><span>${macro(s)}</span><span>${micro(s)}</span>`;
A.pick = el => portionSheet(getFood(el.dataset.id));
I.grams = el => { $('#gRes').innerHTML = resLine(scale(ui.cur, num(el.value))); };
A.setG = el => { const i = $('#gInp'); i.value = el.dataset.v; I.grams(i); };
A.addEntry = () => {
  const g = num($('#gInp').value), f = ui.cur;
  if (g <= 0) return toast(t('Введи вагу порції в грамах'));
  pushEntry({ name: fname(f), g: Math.round(g), ...scale(f, g), foodId: f.id });
  touchRecent(f.id); save(); closeSheet(); app.render(); toast(t('Додано: {0}', fname(f)));
};
A.fav = el => {
  const id = ui.cur.id, on = S.favs.includes(id);
  S.favs = on ? S.favs.filter(x => x !== id) : [id, ...S.favs]; save();
  el.textContent = on ? t('☆ В улюблені') : t('★ В улюблених');
};
A.delFood = () => {
  const id = ui.cur.id;
  S.foods = S.foods.filter(f => f.id !== id); S.favs = S.favs.filter(x => x !== id); S.recent = S.recent.filter(x => x !== id);
  save(); renderAdd(); toast(t('Продукт видалено з каталогу'));
};

/* ---------- Свій продукт ---------- */
function foodForm(f = {}, barcode = '') {
  ui.editId = f.id || null; ui.newBarcode = barcode || f.barcode || '';
  const fld = (id, l, v, mode = 'decimal') => `<div><label class="fl">${l}</label><input class="inp" id="${id}" inputmode="${mode}" value="${v ?? ''}"></div>`;
  sheet(`${head(f.id ? t('Редагувати продукт') : t('Свій продукт'), 'backAdd')}
    ${barcode ? `<p class="muted">${t('Штрихкод {0} не знайдено в базі. Заповни дані з упаковки — наступного разу сканер його впізнає.', esc(barcode))}</p>` : ''}
    <label class="fl">${t('Назва')}</label><input class="inp" id="fName" placeholder="${t('Наприклад: Гречка')}" value="${esc(f.id ? fname(f) : '')}">
    <label class="fl">${t('Калорії на 100 г')}</label><input class="inp xl" id="fKcal" inputmode="decimal" placeholder="105" value="${f.kcal ?? ''}">
    <div class="grid3">${fld('fP', t('Білки, г'), f.p)}${fld('fF', t('Жири, г'), f.f)}${fld('fC', t('Вуглеводи, г'), f.c)}</div>
    <div class="grid3">${fld('fFi', t('Клітковина, г'), f.fi)}${fld('fSu', t('Цукор, г'), f.su)}${fld('fSa', t('Сіль, г'), f.sa)}</div>
    <label class="fl">${t('Звична порція, г (необов\'язково)')}</label><input class="inp" id="fPortion" inputmode="numeric" placeholder="100" value="${f.portion ?? ''}">
    <button class="btn primary" data-a="saveFood">${t('Зберегти')}</button>`);
}
A.openFood = () => foodForm();
A.editFood = () => foodForm(ui.cur);
A.saveFood = () => {
  const name = $('#fName').value.trim(), kcal = num($('#fKcal').value);
  if (!name) return toast(t('Введи назву продукту'));
  if (kcal <= 0 && $('#fKcal').value.trim() === '') return toast(t('Введи калорії на 100 г'));
  const data = { name, kcal: Math.round(kcal), p: r1(num($('#fP').value)), f: r1(num($('#fF').value)), c: r1(num($('#fC').value)),
    fi: r1(num($('#fFi').value)), su: r1(num($('#fSu').value)), sa: Math.round(num($('#fSa').value) * 100) / 100, portion: Math.round(num($('#fPortion').value)) || undefined };
  let food = S.foods.find(f => f.id === ui.editId);
  if (food) Object.assign(food, data);
  else { food = { id: 'u' + uid(), ...data }; if (ui.newBarcode) food.barcode = ui.newBarcode; S.foods.unshift(food); }
  save(); portionSheet(food); toast(t('Збережено в каталог'));
};

/* ---------- Швидкий запис ---------- */
A.openQuick = () => sheet(`${head(t('Швидкий запис'), 'backAdd')}
  <p class="muted">${t('Коли знаєш калорії страви й не хочеш шукати її в каталозі.')}</p>${mealSeg()}
  <label class="fl">${t('Назва')}</label><input class="inp" id="qName" placeholder="${t('Наприклад: Обід у кафе')}">
  <label class="fl">${t('Калорії')}</label><input class="inp xl" id="qKcal" inputmode="decimal" placeholder="450">
  <div class="grid3"><div><label class="fl">${t('Білки, г')}</label><input class="inp" id="qP" inputmode="decimal"></div><div><label class="fl">${t('Жири, г')}</label><input class="inp" id="qF" inputmode="decimal"></div><div><label class="fl">${t('Вуглеводи, г')}</label><input class="inp" id="qC" inputmode="decimal"></div></div>
  <button class="btn primary" data-a="addQuick">${t('Додати в')} <span id="addTo">${mealName()}</span></button>`);
A.addQuick = () => {
  const kcal = num($('#qKcal').value);
  if (kcal <= 0) return toast(t('Введи кількість калорій'));
  pushEntry({ name: $('#qName').value.trim() || t('Швидкий запис'), g: null, kcal: Math.round(kcal), p: r1(num($('#qP').value)), f: r1(num($('#qF').value)), c: r1(num($('#qC').value)) });
  closeSheet(); app.render(); toast(t('Додано'));
};

/* ---------- Редагування запису ---------- */
A.editEntry = el => {
  const e = dayMut(ui.date).entries.find(x => x.id === el.dataset.id);
  if (!e) return;
  ui.entry = e; ui.meal = e.meal;
  sheet(`${head(e.name)}${mealSeg()}
    <label class="fl">${e.g ? t('Скільки грамів') : t('Калорії')}</label>
    <input class="inp xl" id="eVal" inputmode="decimal" value="${e.g || e.kcal}">
    <button class="btn primary" data-a="saveEntry">${t('Зберегти')}</button>
    <button class="btn ghost danger" data-a="delEntry">${t('Видалити запис')}</button>`);
};
A.saveEntry = () => {
  const e = ui.entry, v = num($('#eVal').value);
  if (v <= 0) return toast(t('Значення має бути більше нуля'));
  if (e.g) {
    const k = v / e.g; e.kcal = Math.round(e.kcal * k);
    for (const f of ['p', 'f', 'c', 'fi', 'su']) e[f] = r1((e[f] || 0) * k);
    e.sa = Math.round((e.sa || 0) * k * 100) / 100; e.g = Math.round(v);
  } else e.kcal = Math.round(v);
  e.meal = ui.meal; save(); closeSheet(); app.render();
};
A.delEntry = () => { const d = dayMut(ui.date); d.entries = d.entries.filter(x => x !== ui.entry); save(); closeSheet(); app.render(); toast(t('Запис видалено')); };

/* ---------- Рецепт ---------- */
const recSum = () => {
  const r = ui.rec, tt = r.items.reduce((s, i) => { const x = scale(i.food, i.g); s.g += i.g; for (const k of ['kcal', 'p', 'f', 'c', 'fi', 'su', 'sa']) s[k] += x[k]; return s; }, { g: 0, kcal: 0, p: 0, f: 0, c: 0, fi: 0, su: 0, sa: 0 });
  const total = num(r.total) || tt.g, k = total ? 100 / total : 0;
  return { t: tt, total, per: { kcal: Math.round(tt.kcal * k), p: r1(tt.p * k), f: r1(tt.f * k), c: r1(tt.c * k), fi: r1(tt.fi * k), su: r1(tt.su * k), sa: Math.round(tt.sa * k * 100) / 100 } };
};
const recItems = () => ui.rec.items.map((i, n) => `<div class="recrow"><span>${esc(fname(i.food))}</span><input class="inp sm" inputmode="decimal" data-i="recG" data-n="${n}" value="${i.g}" aria-label="${t('Грами')}"><small>${t('г')}</small><button class="ic" data-a="recDel" data-n="${n}" aria-label="${t('Прибрати')}">✕</button></div>`).join('') || `<p class="muted">${t('Знайди інгредієнти через пошук вище.')}</p>`;
const recInfo = () => { const s = recSum(); return ui.rec.items.length ? `<b>${s.per.kcal} ${t('ккал на 100 г')}</b><span>${t('уся страва: {0} ккал, {1} г', fmt(s.t.kcal), fmt(s.total))} · ${macro(s.per)}</span>` : ''; };
A.openRecipe = () => {
  ui.rec = { items: [], total: '' };
  sheet(`${head(t('Новий рецепт'), 'backAdd')}
    <label class="fl">${t('Назва страви')}</label><input class="inp" id="recName" placeholder="${t('Наприклад: Мій борщ')}">
    <label class="fl">${t('Інгредієнти')}</label><input class="inp" type="search" placeholder="${t('Пошук інгредієнта')}" data-i="recSearch" id="recQ">
    <div id="recRes" class="list"></div><div id="recItems">${recItems()}</div>
    <label class="fl">${t('Вага готової страви, г (якщо відрізняється від суми)')}</label><input class="inp" inputmode="decimal" data-i="recTotal" placeholder="${t('сума інгредієнтів')}">
    <div class="result" id="recInfo"></div>
    <button class="btn primary" data-a="saveRecipe">${t('Зберегти рецепт')}</button>`, { full: true });
};
const recRefresh = () => { $('#recInfo').innerHTML = recInfo(); };
I.recSearch = el => { $('#recRes').innerHTML = el.value.trim() ? search(el.value, allFoods()).slice(0, 6).map(f => `<button class="row" data-a="recAdd" data-id="${f.id}"><span class="rn">${esc(fname(f))}</span><b>${f.kcal}<small> ${t('ккал/100 г')}</small></b></button>`).join('') : ''; };
A.recAdd = el => { ui.rec.items.push({ food: getFood(el.dataset.id), g: 100 }); $('#recQ').value = ''; $('#recRes').innerHTML = ''; $('#recItems').innerHTML = recItems(); recRefresh(); };
A.recDel = el => { ui.rec.items.splice(+el.dataset.n, 1); $('#recItems').innerHTML = recItems(); recRefresh(); };
I.recG = el => { ui.rec.items[+el.dataset.n].g = num(el.value); recRefresh(); };
I.recTotal = el => { ui.rec.total = el.value; recRefresh(); };
A.saveRecipe = () => {
  const name = $('#recName').value.trim(), s = recSum();
  if (!name) return toast(t('Введи назву страви'));
  if (!ui.rec.items.length || !s.total) return toast(t('Додай хоча б один інгредієнт'));
  const food = { id: 'u' + uid(), name, ...s.per, recipe: true };
  S.foods.unshift(food); save(); portionSheet(food); toast(t('Рецепт збережено в каталог'));
};

/* ---------- Розпізнавання: фото, голос, текст (Gemini) ---------- */
const needKey = (title, back) => sheet(`${head(title, back)}
  <p>${t('Щоб розпізнавати їжу, потрібен безкоштовний ключ Google Gemini. Він вставляється один раз у налаштуваннях.')}</p>
  <button class="btn primary" data-a="goSettings">${t('Відкрити налаштування')}</button>`);
A.goSettings = () => { closeSheet(); ui.tab = 'profile'; ui.sub = 'settings'; app.render(); setTimeout(() => $('#gkey')?.scrollIntoView({ block: 'center' }), 50); };

// Фото: можна додати до 3 ракурсів однієї страви
A.openAI = () => {
  ui.ai = { src: 'photo', token: 0, imgs: [], hint: '' };
  if (!S.settings.geminiKey) return needKey(t('Аналіз фото'), 'backAdd');
  photoStage();
};
function photoStage(err) {
  const a = ui.ai;
  sheet(`${head(t('Аналіз фото'), 'backAdd')}
    ${a.imgs.length ? `<div class="thumbs">${a.imgs.map((m, n) => `<div class="thumb"><img src="${m.dataUrl}" alt=""><button class="ic" data-a="aiImgDel" data-n="${n}" aria-label="${t('Прибрати')}">✕</button></div>`).join('')}</div>`
      : `<p class="muted">${t('Сфотографуй тарілку так, щоб було видно всю їжу. Можна додати до 3 ракурсів — це підвищує точність.')}</p>`}
    ${err ? `<p class="err">${esc(err)}</p>` : ''}
    <label class="fl">${t('Уточнення (необов\'язково)')}</label><input class="inp" id="aiHint" data-i="aiHint" placeholder="${t('Наприклад: каша на молоці, порція велика')}" value="${esc(a.hint)}">
    ${a.imgs.length < 3 ? `<label class="btn ${a.imgs.length ? 'soft' : 'primary'}">📷 ${a.imgs.length ? t('Додати ще фото') : t('Зробити фото')}<input type="file" accept="image/*" capture="environment" hidden data-c="aiFile"></label>
    <label class="btn soft">🖼 ${t('Вибрати з галереї')}<input type="file" accept="image/*" multiple hidden data-c="aiFile"></label>` : ''}
    ${a.imgs.length ? `<button class="btn primary" data-a="aiRun">${t('Розпізнати')}</button>` : ''}`);
}
I.aiHint = el => { ui.ai.hint = el.value; };
C.aiFile = async el => {
  const files = [...el.files].slice(0, 3 - ui.ai.imgs.length);
  if (!files.length) return;
  try { for (const f of files) ui.ai.imgs.push(await fileToJpegBase64(f)); photoStage(); }
  catch (e) { photoStage(e.message); }
};
A.aiImgDel = el => { ui.ai.imgs.splice(+el.dataset.n, 1); photoStage(); };
A.aiRun = () => runAI();

async function runAI() {
  const a = ui.ai, token = ++a.token;
  sheet(`${head(a.src === 'photo' ? t('Аналіз фото') : t('Голосовий запис'))}${a.imgs?.[0] ? `<img class="preview" src="${a.imgs[0].dataUrl}" alt="">` : ''}<div class="loading"><i></i>${a.src === 'photo' ? t('Розпізнаю їжу…') : t('Слухаю й рахую…')}</div>`);
  try {
    const items = a.src === 'photo' ? await analyzePhotos(a.imgs.map(m => m.base64), a.hint)
      : a.src === 'voice' ? await analyzeAudio(a.audio, a.hint) : await analyzeText(a.text, a.hint);
    if (a.token !== token) return;
    a.items = items.map(i => ({ ...i, base: { ...i } }));
    aiResult();
  } catch (e) {
    if (a.token !== token) return;
    sheet(`${head(t('Помилка'))}<p class="err">${esc(e.message === 'NO_KEY' ? t('Спершу додай ключ Gemini в налаштуваннях.') : e.message)}</p>
      <button class="btn soft" data-a="aiRetry">${t('Спробувати ще раз')}</button>`);
  }
}
A.aiRetry = () => (ui.ai.src === 'photo' ? ui.ai.imgs.length ? runAI() : A.openAI() : ui.ai.audio || ui.ai.text ? runAI() : A.openVoice());

const aiTotal = () => `${t('Разом')}: <b>${fmt(ui.ai.items.reduce((s, i) => s + i.kcal, 0))} ${t('ккал')}</b>`;
const aiNote = i => i.conf === 'low' ? `<span class="warn">⚠ ${t('перевір')}</span>` : i.fixed ? `<span class="warn">≈ ${t('калорії уточнено за БЖВ')}</span>` : '';
const aiMeta = i => `${macro(i)} · ${t('Клітк.')} ${fmt1(i.fi || 0)}`;
function aiResult() {
  const a = ui.ai, it = a.items;
  sheet(`${head(t('Результат'), a.src === 'photo' ? 'backPhoto' : 'openVoice')}${a.imgs?.[0] ? `<img class="preview sm" src="${a.imgs[0].dataUrl}" alt="">` : ''}
    ${it.length ? `${mealSeg()}<div id="aiRows">${it.map((i, n) => `<div class="airow">
      <input class="inp" data-i="aiName" data-n="${n}" value="${esc(i.name)}" aria-label="${t('Назва')}">
      <div class="aiflds"><label><input class="inp sm" inputmode="decimal" data-i="aiG" data-n="${n}" value="${i.g}"><small>${t('г')}</small></label>
        <label><input class="inp sm" inputmode="decimal" data-i="aiK" data-n="${n}" id="aiK${n}" value="${i.kcal}"><small>${t('ккал')}</small></label>
        <span class="muted" id="aiM${n}">${aiMeta(i)}</span><span id="aiN${n}">${aiNote(i)}</span><button class="ic" data-a="aiDel" data-n="${n}" aria-label="${t('Прибрати')}">✕</button></div></div>`).join('')}</div>
      <div class="result" id="aiTotal">${aiTotal()}</div>
      <button class="btn primary" data-a="aiAdd">${t('Додати в')} <span id="addTo">${mealName()}</span></button>
      <label class="fl">${t('Щось не так? Уточни й перерахуй')}</label>
      <div class="btnrow"><input class="inp" id="aiFix" placeholder="${t('Наприклад: порція вдвічі менша, без цукру')}"><button class="btn soft" data-a="aiFixGo">${t('Перерахувати')}</button></div>
      <p class="muted center">${t('Оцінка приблизна. Змінюєш грами — калорії перераховуються.')}</p>`
    : `<p>${t('Їжі не знайшов. Спробуй ще раз — ближче, при кращому світлі або чіткіше.')}</p><button class="btn soft" data-a="aiRetryNew">${t('Спробувати ще раз')}</button>`}`, { full: true });
}
A.backPhoto = () => photoStage();
A.aiRetryNew = () => (ui.ai.src === 'photo' ? photoStage() : A.openVoice());
A.aiFixGo = () => { const v = $('#aiFix').value.trim(); if (!v) return toast(t('Напиши, що виправити')); ui.ai.hint = [ui.ai.hint, v].filter(Boolean).join('. '); runAI(); };
I.aiName = el => { ui.ai.items[+el.dataset.n].name = el.value; };
I.aiG = el => {
  const n = +el.dataset.n, i = ui.ai.items[n], g = num(el.value), k = i.base.g ? g / i.base.g : 1;
  Object.assign(i, { g: Math.round(g), kcal: Math.round(i.base.kcal * k), p: r1(i.base.p * k), f: r1(i.base.f * k), c: r1(i.base.c * k), fi: r1(i.base.fi * k), su: r1(i.base.su * k), sa: Math.round(i.base.sa * k * 100) / 100 });
  $('#aiK' + n).value = i.kcal; $('#aiM' + n).textContent = aiMeta(i); $('#aiTotal').innerHTML = aiTotal();
};
I.aiK = el => { const i = ui.ai.items[+el.dataset.n]; i.kcal = Math.round(num(el.value)); i.fixed = false; $('#aiN' + el.dataset.n).innerHTML = aiNote(i); $('#aiTotal').innerHTML = aiTotal(); };
A.aiDel = el => { ui.ai.items.splice(+el.dataset.n, 1); aiResult(); };
A.aiAdd = () => {
  const items = ui.ai.items.filter(i => i.name.trim() && i.kcal > 0);
  if (!items.length) return toast(t('Немає що додавати'));
  items.forEach(i => pushEntry({ name: i.name.trim(), g: i.g || null, kcal: i.kcal, p: i.p, f: i.f, c: i.c, fi: i.fi, su: i.su, sa: i.sa, src: ui.ai.src === 'photo' ? 'photo' : 'voice' }));
  closeSheet(); app.render(); toast(t('Додано страв: {0}', items.length));
};

/* ---------- Голосовий запис ---------- */
let recTimer = null, recStart = 0;
const stopTick = () => { clearInterval(recTimer); recTimer = null; };
A.openVoice = (_, auto) => {
  ui.ai = { src: 'voice', token: 0, hint: '' };
  if (!S.settings.geminiKey) return needKey(t('Голосовий запис'), 'backAdd');
  sheet(`${head(t('Голосовий запис'), 'backAdd')}${mealSeg()}
    <p class="muted center" id="vMsg">${canRecord() ? t('Натисни на мікрофон і скажи, що ти з\'їв. Наприклад: «два яйця і шматок хліба з маслом».') : t('Запис голосу тут недоступний. Напиши текстом нижче.')}</p>
    ${canRecord() ? `<button class="mic" id="micBtn" data-a="micToggle" aria-label="${t('Запис')}"><span>🎤</span></button><div class="center vtime" id="vTime"></div>` : ''}
    <label class="fl">${t('Або напиши текстом')}</label>
    <div class="btnrow"><input class="inp" id="vText" placeholder="${t('Наприклад: тарілка борщу і дві скибки хліба')}"><button class="btn soft" data-a="voiceText">${t('Додати')}</button></div>`,
    { onClose: () => { stopTick(); cancelRecord(); } });
  if (auto === true && canRecord()) setTimeout(() => A.micToggle(), 350);
};
A.voiceText = () => {
  const v = $('#vText').value.trim();
  if (!v) return toast(t('Напиши, що ти їв'));
  ui.ai.src = 'text'; ui.ai.text = v; runAI();
};
A.micToggle = async () => {
  const b = $('#micBtn'); if (!b) return;
  if (b.classList.contains('rec')) return finishRecording();
  try {
    await startRecord(finishRecording);
    b.classList.add('rec'); recStart = Date.now();
    $('#vMsg').textContent = t('Слухаю… Натисни ще раз, коли скажеш.');
    stopTick(); recTimer = setInterval(() => { const s = Math.floor((Date.now() - recStart) / 1000), el = $('#vTime'); if (el) el.textContent = `0:${String(s).padStart(2, '0')}`; }, 300);
  } catch (e) {
    const m = $('#vMsg'); if (m) m.textContent = t('Мікрофон недоступний. Дозволь доступ до мікрофона або напиши текстом.');
  }
};
async function finishRecording() {
  stopTick();
  if (!$('#micBtn')?.classList.contains('rec')) return;
  const token = ui.ai.token;
  try {
    const { base64, seconds } = await stopRecord();
    if (ui.ai.token !== token) return;
    if (seconds < 1) { const m = $('#micBtn'); m?.classList.remove('rec'); $('#vMsg').textContent = t('Запис надто короткий. Спробуй ще раз.'); return; }
    ui.ai.src = 'voice'; ui.ai.audio = base64; runAI();
  } catch (e) {
    $('#micBtn')?.classList.remove('rec');
    const m = $('#vMsg'); if (m) m.textContent = t('Не вдалося обробити запис. Спробуй ще раз або напиши текстом.');
  }
}

/* ---------- Сканер штрихкодів ---------- */
A.openScan = () => {
  sheet(`${head(t('Сканер штрихкоду'), 'backAdd')}
    <div class="scanbox"><video id="scanVideo" playsinline muted></video><div class="scanline"></div></div>
    <p class="muted center" id="scanMsg">${t('Наведи камеру на штрихкод упаковки')}</p>
    <div class="btnrow"><input class="inp" id="codeInp" inputmode="numeric" placeholder="${t('або введи цифри коду')}"><button class="btn soft" data-a="codeGo">${t('Знайти')}</button></div>`, { onClose: stopScan });
  startScan($('#scanVideo'), handleCode).catch(() => { const m = $('#scanMsg'); if (m) m.textContent = t('Камера недоступна. Дозволь доступ до камери або введи код вручну.'); });
};
A.codeGo = () => { const c = $('#codeInp').value.replace(/\D/g, ''); if (c.length < 6) return toast(t('Введи цифри штрихкоду')); stopScan(); handleCode(c); };
async function handleCode(code) {
  const known = S.foods.find(f => f.barcode === code);
  if (known) return portionSheet(known);
  sheet(`${head(t('Сканер штрихкоду'), 'openScan')}<div class="loading"><i></i>${t('Шукаю продукт {0}…', esc(code))}</div>`);
  try {
    const p = await lookupBarcode(code);
    if (!p) return foodForm({}, code);
    const food = { id: 'u' + uid(), ...p };
    S.foods.unshift(food); save(); portionSheet(food); toast(t('Продукт знайдено й додано в каталог'));
  } catch (e) {
    toast(navigator.onLine ? e.message : t('Немає інтернету — заповни продукт вручну'));
    foodForm({}, code);
  }
}

/* ---------- Активність ---------- */
const actRes = () => { const a = ui.act; return `<b>−${fmt(actKcal(ACTS[a.i][1], lastWeight(), a.min))} ${t('ккал')}</b><span>${t(ACTS[a.i][0])}, ${a.min} ${t('хв')}</span>`; };
A.openAct = () => {
  ui.act = { i: 0, min: 30 };
  sheet(`${head(t('Додати активність'))}
    <div class="chips wrap">${ACTS.map((a, i) => `<button class="chip${i === 0 ? ' on' : ''}" data-a="actPick" data-n="${i}">${t(a[0])}</button>`).join('')}</div>
    <label class="fl">${t('Тривалість, хв')}</label><input class="inp xl" inputmode="numeric" data-i="actMin" value="30">
    <div class="result" id="actRes">${actRes()}</div>
    <button class="btn primary" data-a="actAdd">${t('Додати')}</button>
    <label class="fl">${t('Або впиши свою')}</label>
    <div class="btnrow"><input class="inp" id="actName" placeholder="${t('Назва')}"><input class="inp" id="actK" inputmode="numeric" placeholder="${t('ккал')}"><button class="btn soft" data-a="actCustom">OK</button></div>`);
};
A.actPick = el => { ui.act.i = +el.dataset.n; el.parentNode.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c === el)); $('#actRes').innerHTML = actRes(); };
I.actMin = el => { ui.act.min = Math.max(0, Math.round(num(el.value))); $('#actRes').innerHTML = actRes(); };
const pushAct = a => { dayMut(ui.date).acts.push({ id: uid(), ...a }); save(); closeSheet(); app.render(); toast(t('Активність додано')); };
A.actAdd = () => { const a = ui.act; if (a.min <= 0) return toast(t('Введи тривалість')); pushAct({ name: t(ACTS[a.i][0]), min: a.min, kcal: actKcal(ACTS[a.i][1], lastWeight(), a.min) }); };
A.actCustom = () => { const k = Math.round(num($('#actK').value)); if (k <= 0) return toast(t('Введи спалені калорії')); pushAct({ name: $('#actName').value.trim() || t('Активність'), kcal: k }); };
