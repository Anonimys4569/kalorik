import './sheets.js';
import { S, load, save, dkey, parseKey, shift, day, dayMut, totals, streak, setWeight, lastWeight } from './store.js';
import { norm, ACTIVITY, GOALS, tdee, weightTrend, calorieRate, daysToGoal } from './calc.js';
import { barChart, lineChart, ring } from './charts.js';
import { applyReminders, canNotify } from './notify.js';
import { progress, checkNew } from './achievements.js';
import { syncWidget, listenLinks } from './widget.js';
import { t, pl, lang, LANGS, fmt1, longDate, weekdayShort } from './i18n.js';
import { ui, A, C, app, $, esc, num, fmt, MEALS, dateLabel, shortDate, toast } from './ui.js';

function applyTheme() {
  const th = S.settings.theme;
  const dark = th === 'auto' ? matchMedia('(prefers-color-scheme: dark)').matches : th === 'dark';
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

/* ---------- Підказка встановлення на iPhone (лише у веб-версії в браузері) ---------- */
const isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const standalone = navigator.standalone === true || matchMedia('(display-mode: standalone)').matches;
const shareIcon = () => `<svg class="shr" viewBox="0 0 24 24" aria-label="${t('Поділитися')}"><path d="M12 3v12M8 7l4-4 4 4M6 11H5v9h14v-9h-1" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
function installHint() {
  if (canNotify() || !isIOS || standalone || S.settings.hideInstall) return '';
  return `<section class="card install"><button class="ic" data-a="hideInstall" aria-label="${t('Сховати підказку')}">✕</button>
    <b>${t('Встанови Калорік на робочий стіл')}</b>
    <ol><li>${t('Натисни «Поділитися» {0} внизу Safari.', shareIcon())}</li><li>${t('Вибери «На початковий екран».')}</li><li>${t('Натисни «Додати» і запускай Калорік з іконки.')}</li></ol>
    <small>${t('Зроби це до заповнення даних: записи з вкладки Safari в ярлик не переносяться.')}</small></section>`;
}
A.hideInstall = () => { S.settings.hideInstall = true; save(); app.render(); };

/* ---------- Мова ---------- */
const langSeg = () => `<div class="seg">${LANGS.map(([v, l]) => `<button class="${lang() === v ? 'on' : ''}" data-a="setLang" data-v="${v}">${l}</button>`).join('')}</div>`;
A.setLang = el => {
  S.settings.lang = el.dataset.v; document.documentElement.lang = lang(); save();
  if (canNotify()) applyReminders().catch(() => {});
  app.render(); syncWidget();
};

/* ---------- Форма профілю (онбординг і вкладка «Профіль») ---------- */
function profileForm() {
  const p = S.profile;
  const seg = (field, opts) => `<div class="seg">${opts.map(([v, l]) => `<button class="${p[field] === v ? 'on' : ''}" data-a="setP" data-f="${field}" data-v="${v}">${l}</button>`).join('')}</div>`;
  return `
    <label class="fl">${t('Стать')}</label>${seg('sex', [['m', t('Чоловік')], ['f', t('Жінка')]])}
    <div class="grid3">
      <div><label class="fl">${t('Вік')}</label><input class="inp" inputmode="numeric" data-c="pnum" data-f="age" value="${p.age}"></div>
      <div><label class="fl">${t('Зріст, см')}</label><input class="inp" inputmode="numeric" data-c="pnum" data-f="height" value="${p.height}"></div>
      <div><label class="fl">${t('Вага, кг')}</label><input class="inp" inputmode="decimal" data-c="pnum" data-f="weight" value="${p.weight}"></div>
    </div>
    <label class="fl">${t('Активність')}</label>
    <select class="inp" data-c="psel" data-f="activity">${ACTIVITY.map(a => `<option value="${a.id}" ${p.activity === a.id ? 'selected' : ''}>${a.name} — ${a.hint}</option>`).join('')}</select>
    <label class="fl">${t('Ціль')}</label>${seg('goal', GOALS.map(g => [g.id, g.name]))}`;
}
A.setP = el => { S.profile[el.dataset.f] = el.dataset.v; save(); app.render(); };
// Після введення оновлюємо лише картку норми: повний перерендер «з'їдав» би наступний дотик по кнопці.
const refreshNorm = () => document.querySelectorAll('.normcard').forEach(el => { el.outerHTML = normCard(); });
C.psel = el => { S.profile[el.dataset.f] = el.value; save(); refreshNorm(); };
C.pnum = el => {
  const f = el.dataset.f, lim = { age: [10, 100], height: [100, 230], weight: [30, 300] }[f];
  const v = Math.min(lim[1], Math.max(lim[0], num(el.value) || S.profile[f]));
  if (f === 'weight') setWeight(dkey(), Math.round(v * 10) / 10); else S.profile[f] = Math.round(v);
  el.value = S.profile[f]; save(); refreshNorm();
};

function normCard() {
  const n = norm(S.profile);
  return `<div class="card normcard">
    <div class="big">${fmt(n.kcal)} <small>${t('ккал на день')}</small></div>
    <div class="macrorow"><span class="pill p">${t('Білки')} ${n.p} ${t('г')}</span><span class="pill f">${t('Жири')} ${n.f} ${t('г')}</span><span class="pill c">${t('Вуглеводи')} ${n.c} ${t('г')}</span></div>
    <div class="muted">${t('Вода')}: ${fmt(n.water)} ${t('мл')}${n.auto ? ` · ${t('базовий обмін {0} ккал · витрата за день {1} ккал', fmt(n.bmr), fmt(n.tdee))}` : ` · ${t('норму задано вручну')}`}</div>
    <div class="muted">${t('Клітковина')} ≥ ${n.fi} ${t('г')} · ${t('Цукор')} ≤ ${n.su} ${t('г')} · ${t('Сіль')} ≤ ${n.sa} ${t('г')}</div>
  </div>`;
}

function onboarding() {
  return `<div class="onb">
    <div class="logo">${t('Калорік')}</div>
    ${langSeg()}
    ${installHint()}
    <p class="lead">${t('Розкажи про себе — порахую твою денну норму калорій, білків, жирів і вуглеводів.')}</p>
    <div class="card">${profileForm()}</div>
    ${normCard()}
    <button class="btn primary" data-a="start">${t('Почати')}</button>
  </div>`;
}
A.start = () => { S.onboarded = true; setWeight(dkey(), S.profile.weight); save(); app.render(); };

/* ---------- Спільні шматки ---------- */
const bar = (cls, name, v, max, limit) => {
  const over = limit && v > max;
  return `<div class="mbar"><div class="mhead"><span>${name}</span><b class="${over ? 'bad' : ''}">${fmt1(v)}<small> ${limit ? '≤' : '/'} ${max} ${t('г')}</small></b></div><div class="track"><div class="fill ${cls}${over ? ' over' : ''}" style="width:${Math.min(100, max ? v / max * 100 : 0)}%"></div></div></div>`;
};
const microBars = (v, n) => `${bar('fi', t('Клітковина'), v.fi, n.fi)}${bar('su', t('Цукор'), v.su, n.su, true)}${bar('sa', t('Сіль'), v.sa, n.sa, true)}`;

/* ---------- Щоденник ---------- */
function diary() {
  const k = ui.date, d = day(k), tt = totals(k), n = norm(S.profile);
  const left = n.kcal + tt.burned - tt.kcal, over = left < 0;
  const today = k === dkey(), yday = k === shift(dkey(), -1);
  const st = streak();
  const glasses = Math.round(d.water / 250), gl = Math.max(Math.ceil(n.water / 250), glasses);
  return `
  <header class="top">
    <button class="ic" data-a="day" data-n="-1" aria-label="${t('Попередній день')}">‹</button>
    <button class="datebtn" data-a="today"><b>${today ? t('Сьогодні') : yday ? t('Учора') : dateLabel(parseKey(k))}</b>${today || yday ? `<small>${dateLabel(parseKey(k))}</small>` : `<small>${t('натисни, щоб повернутись до сьогодні')}</small>`}</button>
    <button class="ic" data-a="day" data-n="1" aria-label="${t('Наступний день')}" ${today ? 'disabled' : ''}>›</button>
  </header>
  ${installHint()}
  <section class="card hero">
    <div class="ringwrap">${ring(n.kcal + tt.burned ? tt.kcal / (n.kcal + tt.burned) : 0, over)}
      <div class="ringtxt"><b class="${over ? 'bad' : ''}">${fmt(Math.abs(left))}</b><span>${over ? t('ккал понад норму') : t('ккал залишилось')}</span></div></div>
    <div class="herostats">
      <div><span>${t('З\'їдено')}</span><b>${fmt(tt.kcal)}</b></div>
      <div><span>${t('Спалено')}</span><b>${fmt(tt.burned)}</b></div>
      <div><span>${t('Норма')}</span><b>${fmt(n.kcal)}</b></div>
      ${st ? `<div class="streak">🔥 ${st} ${pl(st, 'день|дні|днів')} ${t('поспіль')}</div>` : ''}
    </div>
  </section>
  <section class="card macros">${bar('p', t('Білки'), tt.p, n.p)}${bar('f', t('Жири'), tt.f, n.f)}${bar('c', t('Вуглеводи'), tt.c, n.c)}</section>
  <section class="card macros"><h3>${t('Клітковина, цукор, сіль')}</h3>${microBars(tt, n)}</section>
  ${MEALS.map(m => {
    const es = d.entries.filter(e => e.meal === m.id), sum = es.reduce((s, e) => s + e.kcal, 0);
    return `<section class="card meal">
      <div class="mealhead"><span class="micon">${m.icon}</span><b>${m.name}</b><span class="mk">${sum ? fmt(sum) + ' ' + t('ккал') : ''}</span>
        <button class="addbtn" data-a="openAdd" data-meal="${m.id}" aria-label="${t('Додати в')} ${m.name}">+</button></div>
      ${es.map(e => `<button class="row" data-a="editEntry" data-id="${e.id}"><span class="rn">${esc(e.name)}<small>${e.g ? e.g + ' ' + t('г') + ' · ' : ''}${t('Б')} ${Math.round(e.p || 0)} · ${t('Ж')} ${Math.round(e.f || 0)} · ${t('В')} ${Math.round(e.c || 0)}</small></span><b>${fmt(e.kcal)}</b></button>`).join('')}
    </section>`;
  }).join('')}
  <section class="card">
    <div class="mealhead"><span class="micon">💧</span><b>${t('Вода')}</b><span class="mk">${fmt(d.water)} / ${fmt(n.water)} ${t('мл')}</span></div>
    <div class="glasses">${Array.from({ length: gl }, (_, i) => `<i class="${i < glasses ? 'on' : ''}"></i>`).join('')}</div>
    <div class="btnrow"><button class="btn ghost" data-a="water" data-n="-250" ${d.water ? '' : 'disabled'}>− 250 ${t('мл')}</button><button class="btn soft" data-a="water" data-n="250">+ 250 ${t('мл')}</button></div>
  </section>
  <section class="card meal">
    <div class="mealhead"><span class="micon">🏃</span><b>${t('Активність')}</b><span class="mk">${tt.burned ? '−' + fmt(tt.burned) + ' ' + t('ккал') : ''}</span>
      <button class="addbtn" data-a="openAct" aria-label="${t('Додати активність')}">+</button></div>
    ${d.acts.map(a => `<button class="row" data-a="delAct" data-id="${a.id}"><span class="rn">${esc(a.name)}<small>${a.min ? a.min + ' ' + t('хв') + ' · ' : ''}${t('натисни, щоб видалити')}</small></span><b>−${fmt(a.kcal)}</b></button>`).join('')}
  </section>`;
}
A.day = el => { const k = shift(ui.date, +el.dataset.n); if (k <= dkey()) { ui.anim = +el.dataset.n > 0 ? 'fwd' : 'back'; ui.date = k; app.render(); scrollTo(0, 0); } };
A.today = () => { ui.anim = 'fwd'; ui.date = dkey(); app.render(); };
A.water = el => { const d = dayMut(ui.date); d.water = Math.max(0, d.water + +el.dataset.n); save(); app.render(); };
A.delAct = el => { const d = dayMut(ui.date); d.acts = d.acts.filter(a => a.id !== el.dataset.id); save(); app.render(); toast(t('Активність видалено')); };

/* ---------- Тижневий підсумок ---------- */
function weekData(off) {
  const end = shift(dkey(), off * 7), keys = Array.from({ length: 7 }, (_, i) => shift(end, i - 6));
  const n = norm(S.profile), ts = keys.map(totals), logged = ts.filter(x => x.kcal > 0);
  const avg = f => logged.length ? logged.reduce((s, x) => s + x[f], 0) / logged.length : 0;
  const ws = S.weights.filter(w => w.d >= keys[0] && w.d <= end), before = [...S.weights].reverse().find(w => w.d < keys[0]);
  const wLast = ws.length ? ws[ws.length - 1].kg : null, wFirst = before ? before.kg : ws.length ? ws[0].kg : null;
  return { keys, end, n, logged: logged.length, kcal: avg('kcal'), p: avg('p'), fi: avg('fi'), su: avg('su'), sa: avg('sa'),
    inNorm: ts.filter(x => x.kcal > 0 && Math.abs(x.kcal - n.kcal) <= n.kcal * 0.1).length,
    water: keys.map(k => day(k).water).filter(Boolean).reduce((a, b, _, r) => a + b / r.length, 0),
    actMin: keys.reduce((s, k) => s + day(k).acts.reduce((a, x) => a + (x.min || 0), 0), 0),
    dw: wLast != null && wFirst != null ? wLast - wFirst : null };
}
function weekVerdict(w, prev) {
  if (w.logged < 3) return t('Записів замало для висновків — веди щоденник хоча б 3 дні на тиждень.');
  const r = w.kcal / w.n.kcal, g = S.profile.goal, notes = [];
  if (Math.abs(r - 1) <= 0.1) notes.push(t('Калорії в нормі — чудовий результат!'));
  else if (r > 1) notes.push(g === 'gain' ? t('Ти трохи вище норми — для набору ваги це нормально.') : t('У середньому ти з\'їдаєш більше норми — спробуй зменшити порції чи солодке.'));
  else notes.push(r < 0.85 ? t('Калорій помітно менше норми — не недоїдай, це шкодить обміну речовин.') : t('Ти трохи нижче норми — це добре, якщо ціль — схуднення.'));
  if (w.p < w.n.p * 0.85) notes.push(t('Білка бракує — додай м\'ясо, яйця, сир кисломолочний чи бобові.'));
  if (w.fi < w.n.fi * 0.7) notes.push(t('Мало клітковини — більше овочів, фруктів і цільного зерна.'));
  if (w.su > w.n.su * 1.3) notes.push(t('Цукру забагато — солодкі напої й десерти варто обмежити.'));
  if (w.sa > w.n.sa * 1.2) notes.push(t('Солі більше норми — менше ковбас, солінь і напівфабрикатів.'));
  if (prev.logged >= 3 && Math.abs(w.kcal - prev.kcal) > 50) notes.push(w.kcal < prev.kcal ? t('Порівняно з минулим тижнем калорій менше на {0}.', fmt(prev.kcal - w.kcal)) : t('Порівняно з минулим тижнем калорій більше на {0}.', fmt(w.kcal - prev.kcal)));
  return notes.join(' ');
}
function weekCard() {
  const off = ui.wk || 0, w = weekData(off), prev = weekData(off - 1);
  const tile = (l, v, s) => `<div class="tile"><span>${l}</span><b>${v}</b><small>${s}</small></div>`;
  return `<section class="card week"><div class="wkhead"><button class="ic" data-a="wk" data-n="-1" aria-label="${t('Попередній тиждень')}">‹</button>
    <div><h3>📅 ${t('Тижневий підсумок')}</h3><small class="muted">${shortDate(parseKey(w.keys[0]))} – ${shortDate(parseKey(w.end))}</small></div>
    <button class="ic" data-a="wk" data-n="1" aria-label="${t('Наступний тиждень')}" ${off >= 0 ? 'disabled' : ''}>›</button></div>
    <div class="tiles">
      ${tile(t('У середньому'), fmt(w.kcal), `${t('ккал')} / ${fmt(w.n.kcal)}`)}
      ${tile(t('Днів у нормі'), w.inNorm, `${t('із')} ${w.logged || 0} ${t('записаних')}`)}
      ${tile(t('Білки'), fmt(w.p), `${t('г')} / ${w.n.p}`)}
      ${tile(t('Вага'), w.dw == null ? '—' : (w.dw > 0 ? '+' : '') + fmt1(w.dw), t('кг за тиждень'))}
      ${tile(t('Вода'), fmt(w.water), t('мл на день'))}
      ${tile(t('Активність'), w.actMin, t('хв за тиждень'))}
    </div>
    <p class="verdict">${weekVerdict(w, prev)}</p></section>`;
}
A.wk = el => { ui.wk = Math.min(0, (ui.wk || 0) + +el.dataset.n); app.render(); };

/* ---------- Статистика ---------- */
function stats() {
  const n = norm(S.profile), keys = Array.from({ length: ui.range }, (_, i) => shift(dkey(), i - ui.range + 1));
  const ts = keys.map(k => totals(k)), logged = ts.filter(x => x.kcal > 0);
  const avg = f => logged.length ? logged.reduce((s, x) => s + x[f], 0) / logged.length : 0;
  const water = keys.map(k => day(k).water).filter(Boolean);
  const pts = keys.map((k, i) => ({ label: ui.range === 7 ? weekdayShort(parseKey(k)) : shortDate(parseKey(k)), v: ts[i].kcal }));
  return `
  <header class="top plain"><h1>${t('Статистика')}</h1></header>
  ${weekCard()}
  <div class="seg wide"><button class="${ui.range === 7 ? 'on' : ''}" data-a="range" data-n="7">${t('Тиждень')}</button><button class="${ui.range === 30 ? 'on' : ''}" data-a="range" data-n="30">${t('Місяць')}</button></div>
  <section class="card"><h3>${t('Калорії по днях')}</h3>${barChart(pts, n.kcal)}
    <div class="legend"><span><i class="lg bar"></i>${t('з\'їдено')}</span><span><i class="lg over"></i>${t('понад норму')}</span><span><i class="lg dash"></i>${t('норма')} ${fmt(n.kcal)}</span></div></section>
  <div class="tiles">
    <div class="tile"><span>${t('У середньому')}</span><b>${fmt(avg('kcal'))}</b><small>${t('ккал на день')}</small></div>
    <div class="tile"><span>${t('Днів із записами')}</span><b>${logged.length}</b><small>${t('із')} ${ui.range}</small></div>
    <div class="tile"><span>${t('Серія')}</span><b>${streak()}</b><small>${t('днів поспіль')}</small></div>
    <div class="tile"><span>${t('Вода')}</span><b>${water.length ? fmt(water.reduce((a, b) => a + b, 0) / water.length) : 0}</b><small>${t('мл на день')}</small></div>
  </div>
  <section class="card macros"><h3>${t('БЖВ у середньому за день')}</h3>${bar('p', t('Білки'), avg('p'), n.p)}${bar('f', t('Жири'), avg('f'), n.f)}${bar('c', t('Вуглеводи'), avg('c'), n.c)}</section>
  <section class="card macros"><h3>${t('Клітковина, цукор, сіль')} — ${t('у середньому за день')}</h3>${microBars({ fi: avg('fi'), su: avg('su'), sa: avg('sa') }, n)}</section>`;
}
A.range = el => { ui.range = +el.dataset.n; app.render(); };

/* ---------- Вага, ціль і прогноз ---------- */
function forecastCard() {
  const gw = S.profile.goalWeight, cur = lastWeight();
  if (!gw) return `<section class="card"><h3>🎯 ${t('Цільова вага')}</h3>
    <p class="muted">${t('Вкажи, до якої ваги хочеш дійти, — покажу прогрес і приблизну дату.')}</p>
    <div class="btnrow"><input class="inp" id="gwInp" inputmode="decimal" placeholder="${Math.round(cur)}" aria-label="${t('Цільова вага, кг')}"><button class="btn soft" data-a="setGoalW">${t('Зберегти')}</button></div></section>`;
  const w0 = S.weights.length ? S.weights[0].kg : cur, total = w0 - gw;
  const pct = Math.abs(total) < 0.05 ? 1 : Math.max(0, Math.min(1, (w0 - cur) / total));
  const left = gw - cur, reached = Math.abs(left) < 0.05 || (total > 0 ? cur <= gw : total < 0 ? cur >= gw : false);
  const p = S.profile, goalNow = left < -0.05 ? 'lose' : left > 0.05 ? 'gain' : 'keep';
  const line = (label, kgw, days) => `<div class="fc"><span>${label}</span><b>${days == null ? t('ціль не наближається') : days === 0 ? t('ціль досягнуто') : `≈ ${longDate(new Date(Date.now() + days * 864e5))}`}</b>${kgw != null ? `<small>${kgw > 0 ? '+' : ''}${fmt1(kgw)} ${t('кг на тиждень')}</small>` : ''}</div>`;
  let body = '';
  if (reached) body = `<p class="goalok">🥇 ${t('Ціль досягнуто! Можна поставити нову або перейти на підтримку ваги.')}</p>`;
  else {
    const trend = weightTrend(S.weights, dkey(), parseKey);
    const ks = Array.from({ length: 14 }, (_, i) => shift(dkey(), -i)), ts = ks.map(totals).filter(x => x.kcal > 0);
    const rate = ts.length >= 3 ? calorieRate(ts.reduce((s, x) => s + x.kcal - x.burned, 0) / ts.length, tdee(p)) : null;
    const safe = Math.sign(left) * 0.5;
    body = (trend != null ? line(t('За динамікою ваги'), trend, daysToGoal(cur, gw, trend)) : `<div class="fc"><span>${t('За динамікою ваги')}</span><small>${t('Запиши вагу ще кілька разів протягом тижня — тоді з\'явиться прогноз.')}</small></div>`)
      + (rate != null ? line(t('За твоїм харчуванням'), rate, daysToGoal(cur, gw, rate)) : `<div class="fc"><span>${t('За твоїм харчуванням')}</span><small>${t('Потрібні записи їжі хоча б за 3 дні.')}</small></div>`)
      + line(t('Безпечний темп 0,5 кг на тиждень'), safe, daysToGoal(cur, gw, safe));
    if (p.goal !== goalNow && !p.manual) body += `<div class="fc warnbox"><small>${t('Твоя ціль в профілі не збігається з цільовою вагою.')}</small><button class="btn soft" data-a="syncGoal" data-v="${goalNow}">${t('Поставити: {0}', GOALS.find(g => g.id === goalNow).name)}</button></div>`;
  }
  return `<section class="card"><h3>🎯 ${t('Цільова вага')}: ${fmt1(gw)} ${t('кг')}</h3>
    <div class="track big"><div class="fill g" style="width:${pct * 100}%"></div></div>
    <div class="goalrow"><span>${fmt1(w0)}</span><b>${reached ? '100 %' : `${Math.round(pct * 100)} % · ${t('залишилось')} ${fmt1(Math.abs(left))} ${t('кг')}`}</b><span>${fmt1(gw)}</span></div>
    ${body}
    <div class="btnrow"><input class="inp" id="gwInp" inputmode="decimal" placeholder="${fmt1(gw)}" aria-label="${t('Цільова вага, кг')}"><button class="btn soft" data-a="setGoalW">${t('Змінити')}</button><button class="btn ghost" data-a="clearGoalW">${t('Скинути')}</button></div>
    <p class="muted">${t('Прогноз орієнтовний: на нього впливають вода в організмі, сон і точність записів.')}</p></section>`;
}
A.setGoalW = () => {
  const v = num($('#gwInp').value);
  if (v < 30 || v > 300) return toast(t('Введи вагу від 30 до 300 кг'));
  S.profile.goalWeight = Math.round(v * 10) / 10; save(); app.render(); toast(t('Ціль збережено'));
};
A.clearGoalW = () => { S.profile.goalWeight = null; save(); app.render(); };
A.syncGoal = el => { S.profile.goal = el.dataset.v; save(); app.render(); toast(t('Ціль у профілі змінено, норму перераховано')); };

function weight() {
  const w = S.weights, cur = lastWeight(), first = w.length ? w[0].kg : cur, diff = cur - first;
  const bmi = cur / ((S.profile.height / 100) ** 2);
  const pts = w.slice(-60).map(x => ({ label: shortDate(parseKey(x.d)), v: x.kg }));
  return `
  <header class="top plain"><h1>${t('Вага')}</h1></header>
  <div class="tiles">
    <div class="tile"><span>${t('Зараз')}</span><b>${fmt1(cur)}</b><small>${t('кг')}</small></div>
    <div class="tile"><span>${t('Зміна')}</span><b>${diff > 0 ? '+' : ''}${diff.toFixed(1)}</b><small>${t('кг від початку')}</small></div>
    <div class="tile"><span>${t('ІМТ')}</span><b>${bmi.toFixed(1)}</b><small>${t('індекс маси тіла')}</small></div>
  </div>
  ${forecastCard()}
  <section class="card"><h3>${t('Записати вагу сьогодні')}</h3>
    <div class="btnrow"><input class="inp" id="wInp" inputmode="decimal" placeholder="${cur}" aria-label="${t('Вага в кілограмах')}"><button class="btn soft" data-a="addWeight">${t('Зберегти')}</button></div></section>
  <section class="card"><h3>${t('Графік')}</h3>${pts.length >= 2 ? lineChart(pts) : `<p class="muted">${t('Запиши вагу хоча б у два різні дні — тут з\'явиться графік.')}</p>`}</section>
  <section class="card meal"><h3>${t('Історія')}</h3>${w.slice(-15).reverse().map(x => `<button class="row" data-a="delWeight" data-d="${x.d}"><span class="rn">${dateLabel(parseKey(x.d))}<small>${t('натисни, щоб видалити')}</small></span><b>${x.kg} ${t('кг')}</b></button>`).join('') || `<p class="muted">${t('Записів ще немає.')}</p>`}</section>`;
}
A.addWeight = () => {
  const v = num($('#wInp').value);
  if (v < 30 || v > 300) return toast(t('Введи вагу від 30 до 300 кг'));
  setWeight(dkey(), Math.round(v * 10) / 10); save(); app.render(); toast(t('Вагу збережено, норму перераховано'));
};
A.delWeight = el => {
  S.weights = S.weights.filter(x => x.d !== el.dataset.d);
  if (S.weights.length) S.profile.weight = S.weights[S.weights.length - 1].kg;
  save(); app.render();
};

/* ---------- Профіль, досягнення, налаштування ---------- */
const subHead = title => `<header class="top"><button class="ic" data-a="sub" data-v="" aria-label="${t('Назад')}">‹</button><div class="datebtn"><b>${title}</b></div><span class="ic ghosted"></span></header>`;
A.sub = el => { ui.sub = el.dataset.v || null; ui.anim = ui.sub ? 'fwd' : 'back'; app.render(); scrollTo(0, 0); };

function profile() {
  if (ui.sub === 'ach') return achScreen();
  if (ui.sub === 'settings') return settingsScreen();
  const m = S.profile.manual, n = norm(S.profile), medals = progress(), got = medals.filter(x => x.done).length;
  const sw = (key, on) => `<button class="sw${on ? ' on' : ''}" data-a="toggle" data-k="${key}" role="switch" aria-checked="${on}"><i></i></button>`;
  return `
  <header class="top plain"><h1>${t('Профіль')}</h1></header>
  <button class="card navrow" data-a="sub" data-v="ach"><span class="micon">🏅</span><span class="rn"><b>${t('Досягнення')}</b><small>${t('Відкрито {0} з {1}', got, medals.length)}</small></span><i>›</i></button>
  <button class="card navrow" data-a="sub" data-v="settings"><span class="micon">⚙️</span><span class="rn"><b>${t('Налаштування')}</b><small>${t('Мова, тема, нагадування, ключ Gemini')}</small></span><i>›</i></button>
  ${normCard()}
  <section class="card"><h3>${t('Мої дані')}</h3>${profileForm()}</section>
  <section class="card"><div class="line"><div><b>${t('Задати норму вручну')}</b><small>${t('замість автоматичного розрахунку')}</small></div>${sw('manual', !!m)}</div>
    ${m ? `<div class="grid4">${[['kcal', t('ккал')], ['p', t('Білки')], ['f', t('Жири')], ['c', t('Вугл.')]].map(([f, l]) => `<div><label class="fl">${l}</label><input class="inp" inputmode="numeric" data-c="manual" data-f="${f}" value="${n[f]}"></div>`).join('')}</div>` : ''}</section>
  <p class="muted center">${t('Калорік 2.0 · усі дані зберігаються на цьому пристрої')}</p>`;
}

function achScreen() {
  const list = progress(), got = list.filter(x => x.done).length;
  return `${subHead(t('Досягнення'))}
  <section class="card"><div class="big">${got} <small>${t('із')} ${list.length}</small></div><div class="track big"><div class="fill g" style="width:${got / list.length * 100}%"></div></div></section>
  <div class="medals">${list.map(m => `<div class="medal${m.done ? ' got' : ''}"><span class="mi">${m.icon}</span><b>${t(m.name)}</b><small>${t(m.desc)}</small>
    ${m.done ? `<em>✓ ${m.date && m.date !== '_' ? dateLabel(parseKey(m.date)) : ''}</em>` : `<div class="track"><div class="fill g" style="width:${m.cur / m.max * 100}%"></div></div><em>${fmt1(m.cur)} / ${m.max}</em>`}</div>`).join('')}</div>`;
}

function settingsScreen() {
  const s = S.settings, r = s.reminders;
  const sw = (key, on) => `<button class="sw${on ? ' on' : ''}" data-a="toggle" data-k="${key}" role="switch" aria-checked="${on}"><i></i></button>`;
  return `${subHead(t('Налаштування'))}
  <section class="card"><h3>🌐 ${t('Мова')}</h3>${langSeg()}</section>
  <section class="card"><h3>${t('Тема')}</h3><div class="seg">${[['dark', t('Темна')], ['light', t('Світла')], ['auto', t('Як у системі')]].map(([v, l]) => `<button class="${s.theme === v ? 'on' : ''}" data-a="theme" data-v="${v}">${l}</button>`).join('')}</div></section>
  <section class="card"><h3>${t('Нагадування')}</h3>
    ${canNotify() ? '' : `<p class="muted">${t('Нагадування працюють у встановленій програмі на телефоні.')}</p>`}
    <div class="line"><div><b>${t('Записати їжу')}</b><small>${t('сніданок, обід, вечеря')}</small></div>${sw('meals', r.meals)}</div>
    ${r.meals ? `<div class="grid3">${r.times.map((tm, i) => `<input class="inp" type="time" data-c="rtime" data-n="${i}" value="${tm}" aria-label="${t('Час нагадування {0}', i + 1)}">`).join('')}</div>` : ''}
    <div class="line"><div><b>${t('Випити води')}</b><small>${t('з {0}:00 до {1}:00', r.waterFrom, r.waterTo)}</small></div>${sw('water', r.water)}</div>
    ${r.water ? `<label class="fl">${t('Як часто')}</label><div class="seg">${[1, 2, 3].map(h => `<button class="${r.waterEvery === h ? 'on' : ''}" data-a="wevery" data-n="${h}">${t('кожні {0} год', h)}</button>`).join('')}</div>` : ''}
    <div class="line"><div><b>${t('Підсумок тижня')}</b><small>${t('щонеділі ввечері')}</small></div>${sw('week', r.week)}</div>
  </section>
  <section class="card"><h3>${t('ШІ-аналіз: фото та голос')}</h3>
    <p class="muted">${t('Фото й голос розпізнає Google Gemini. Створи безкоштовний ключ на aistudio.google.com/apikey і встав його сюди. Ключ зберігається лише на цьому телефоні.')}</p>
    <input class="inp" id="gkey" type="password" autocomplete="off" placeholder="${t('Ключ Gemini API')}" data-c="gkey" value="${esc(s.geminiKey)}">
    ${s.geminiModel ? `<p class="muted">${t('Модель')}: ${esc(s.geminiModel)}</p>` : ''}</section>
  <p class="muted center">${t('Калорік 2.0 · усі дані зберігаються на цьому пристрої')}</p>`;
}
A.theme = el => { S.settings.theme = el.dataset.v; save(); applyTheme(); app.render(); };
A.toggle = async el => {
  const k = el.dataset.k, r = S.settings.reminders;
  if (k === 'manual') { const n = norm(S.profile); S.profile.manual = S.profile.manual ? null : { kcal: n.kcal, p: n.p, f: n.f, c: n.c }; }
  else {
    r[k] = !r[k];
    if (canNotify()) { const ok = await applyReminders().catch(() => false); if (!ok && r[k]) { r[k] = false; toast(t('Дозволь сповіщення в налаштуваннях телефону')); } }
  }
  save(); app.render();
};
C.manual = el => { S.profile.manual[el.dataset.f] = Math.max(0, Math.round(num(el.value))); save(); refreshNorm(); };
C.rtime = el => { if (el.value) { S.settings.reminders.times[+el.dataset.n] = el.value; save(); applyReminders().catch(() => {}); } };
A.wevery = el => { S.settings.reminders.waterEvery = +el.dataset.n; save(); applyReminders().catch(() => {}); app.render(); };
C.gkey = el => { S.settings.geminiKey = el.value.trim(); S.settings.geminiModel = ''; save(); toast(el.value.trim() ? t('Ключ збережено') : t('Ключ видалено')); };

/* ---------- Каркас ---------- */
const TABS = [['diary', 'Щоденник', '📖'], ['stats', 'Статистика', '📊'], ['weight', 'Вага', '⚖️'], ['profile', 'Профіль', '👤']];
const SCREENS = { diary, stats, weight, profile };
app.render = () => {
  const root = $('#app');
  if (!S.onboarded) { root.innerHTML = onboarding(); return; }
  const y = scrollY;
  const tab = tb => `<button class="tab${ui.tab === tb[0] ? ' on' : ''}" data-a="tab" data-t="${tb[0]}"><span>${tb[2]}</span>${t(tb[1])}</button>`;
  const anim = ui.anim ? ` class="anim-${ui.anim}"` : ''; ui.anim = null; // анімація лише при зміні вкладки чи дня
  root.innerHTML = `<main${anim}>${SCREENS[ui.tab]()}</main>
    <nav class="tabbar">${tab(TABS[0])}${tab(TABS[1])}<button class="fab" data-a="openAdd" aria-label="${t('Додати їжу')}">+</button>${tab(TABS[2])}${tab(TABS[3])}</nav>`;
  scrollTo(0, y);
  afterRender();
};
// Після кожного малювання: нові медалі та оновлення віджета.
function afterRender() {
  const { fresh, changed } = checkNew();
  if (changed) save();
  if (fresh.length) setTimeout(() => toast(`🏅 ${fresh.map(m => t(m.name)).join(', ')}`), 500);
  syncWidget();
}
const ORDER = TABS.map(x => x[0]);
A.tab = el => {
  const tb = el.dataset.t;
  if (ui.tab === tb && !ui.sub) return;
  ui.anim = ORDER.indexOf(tb) > ORDER.indexOf(ui.tab) ? 'fwd' : 'back'; // напрямок руху залежить від порядку вкладок
  ui.tab = tb; ui.sub = null; app.render(); scrollTo(0, 0);
};

// Веб-версія (для iPhone): кешуємо файли, щоб програма відкривалась без інтернету.
if (!canNotify() && 'serviceWorker' in navigator && location.protocol === 'https:') navigator.serviceWorker.register('./sw.js').catch(() => {});

load().then(() => {
  applyTheme(); document.documentElement.lang = lang(); app.render();
  if (canNotify()) applyReminders().catch(() => {});
  // Швидкі дії з віджета: kalorik://add відкриває додавання їжі, kalorik://voice — запис голосом.
  listenLinks(act => {
    if (!S.onboarded) return;
    ui.tab = 'diary'; ui.sub = null; ui.date = dkey(); app.render();
    if (act === 'add' || act === 'voice') A.openAdd({ dataset: {} });
    if (act === 'voice') A.openVoice(null, true);
  });
});
