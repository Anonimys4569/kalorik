import { Preferences } from '@capacitor/preferences';

const KEY = 'kalorik_state_v1';
const blank = () => ({
  onboarded: false,
  profile: { sex: 'm', age: 25, height: 175, weight: 70, activity: 'light', goal: 'keep', manual: null, goalWeight: null },
  settings: {
    theme: 'dark', lang: null, geminiKey: '', geminiModel: '',
    reminders: { week: false, meals: false, times: ['08:30', '13:30', '19:00'], water: false, waterEvery: 2, waterFrom: 9, waterTo: 21 },
  },
  foods: [], favs: [], recent: [], days: {}, weights: [], ach: {},
});

export let S = blank();
let timer = null;

export async function load() {
  try {
    const { value } = await Preferences.get({ key: KEY });
    if (value) {
      const saved = JSON.parse(value), d = blank();
      S = { ...d, ...saved, profile: { ...d.profile, ...saved.profile },
        settings: { ...d.settings, ...saved.settings, reminders: { ...d.settings.reminders, ...(saved.settings || {}).reminders } } };
    }
  } catch (e) { console.error('load', e); }
}

export function save() {
  clearTimeout(timer);
  timer = setTimeout(flush, 150);
}
export function flush() {
  clearTimeout(timer);
  return Preferences.set({ key: KEY, value: JSON.stringify(S) }).catch(e => console.error('save', e));
}
document.addEventListener('visibilitychange', () => { if (document.hidden) flush(); });

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
export const dkey = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const parseKey = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
export const shift = (k, n) => { const d = parseKey(k); d.setDate(d.getDate() + n); return dkey(d); };

export function day(k) { return S.days[k] || { entries: [], water: 0, acts: [] }; }
export function dayMut(k) { return S.days[k] || (S.days[k] = { entries: [], water: 0, acts: [] }); }

export function totals(k) {
  const d = day(k), t = { kcal: 0, p: 0, f: 0, c: 0, fi: 0, su: 0, sa: 0, burned: 0 };
  for (const e of d.entries) { t.kcal += e.kcal; t.p += e.p || 0; t.f += e.f || 0; t.c += e.c || 0; t.fi += e.fi || 0; t.su += e.su || 0; t.sa += e.sa || 0; }
  for (const a of d.acts) t.burned += a.kcal;
  return t;
}

export function streak() {
  let k = dkey(), n = 0;
  if (!day(k).entries.length) k = shift(k, -1);
  while (day(k).entries.length) { n++; k = shift(k, -1); }
  return n;
}

export function touchRecent(id) {
  S.recent = [id, ...S.recent.filter(x => x !== id)].slice(0, 30);
}
export function lastWeight() {
  return S.weights.length ? S.weights[S.weights.length - 1].kg : S.profile.weight;
}
export function setWeight(k, kg) {
  const i = S.weights.findIndex(w => w.d === k);
  if (i >= 0) S.weights[i].kg = kg; else S.weights.push({ d: k, kg });
  S.weights.sort((a, b) => a.d.localeCompare(b.d));
  S.profile.weight = S.weights[S.weights.length - 1].kg;
}
