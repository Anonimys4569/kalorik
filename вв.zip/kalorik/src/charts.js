// Прості SVG-графіки без бібліотек.
const W = 340, H = 170, PL = 34, PR = 8, PT = 10, PB = 22;

export function barChart(points, normVal) {
  // points: [{label, v}]
  const max = Math.max(normVal || 0, ...points.map(p => p.v), 1) * 1.12;
  const iw = W - PL - PR, ih = H - PT - PB, bw = iw / points.length;
  const y = v => PT + ih - (v / max) * ih;
  const step = Math.max(1, Math.ceil(points.length / 7));
  let s = `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img">`;
  for (const g of [0.5, 1]) {
    const v = Math.round(max / 1.12 * g);
    s += `<line x1="${PL}" x2="${W - PR}" y1="${y(v)}" y2="${y(v)}" class="grid"/><text x="${PL - 5}" y="${y(v) + 3}" class="ax" text-anchor="end">${v}</text>`;
  }
  points.forEach((p, i) => {
    const x = PL + i * bw + bw * 0.18, w = bw * 0.64, h = Math.max(p.v ? 2 : 0, (p.v / max) * ih);
    const over = normVal && p.v > normVal * 1.05;
    s += `<rect x="${x}" y="${PT + ih - h}" width="${w}" height="${h}" rx="${Math.min(4, w / 2)}" class="bar${over ? ' over' : ''}"/>`;
    if (i % step === 0) s += `<text x="${x + w / 2}" y="${H - 6}" class="ax" text-anchor="middle">${p.label}</text>`;
  });
  if (normVal) s += `<line x1="${PL}" x2="${W - PR}" y1="${y(normVal)}" y2="${y(normVal)}" class="normline"/>`;
  return s + '</svg>';
}

export function lineChart(points) {
  // points: [{label, v}], щонайменше 2
  const vs = points.map(p => p.v);
  let min = Math.min(...vs), max = Math.max(...vs);
  if (max - min < 2) { min -= 1; max += 1; }
  const pad = (max - min) * 0.15; min -= pad; max += pad;
  const iw = W - PL - PR, ih = H - PT - PB;
  const x = i => PL + (points.length === 1 ? iw / 2 : (i / (points.length - 1)) * iw);
  const y = v => PT + ih - ((v - min) / (max - min)) * ih;
  let s = `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img">`;
  for (const g of [0.15, 0.5, 0.85]) {
    const v = min + (max - min) * g;
    s += `<line x1="${PL}" x2="${W - PR}" y1="${y(v)}" y2="${y(v)}" class="grid"/><text x="${PL - 5}" y="${y(v) + 3}" class="ax" text-anchor="end">${v.toFixed(1)}</text>`;
  }
  const d = points.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p.v).toFixed(1)}`).join(' ');
  s += `<path d="${d} L${x(points.length - 1)},${PT + ih} L${x(0)},${PT + ih} Z" class="area"/><path d="${d}" class="line"/>`;
  const step = Math.max(1, Math.ceil(points.length / 5));
  points.forEach((p, i) => {
    if (points.length <= 14) s += `<circle cx="${x(i)}" cy="${y(p.v)}" r="3" class="dot"/>`;
    if (i === points.length - 1 || (i % step === 0 && points.length - 1 - i >= Math.ceil(step / 2) + 1)) s += `<text x="${x(i)}" y="${H - 6}" class="ax" text-anchor="${i === 0 ? 'start' : i === points.length - 1 ? 'end' : 'middle'}">${p.label}</text>`;
  });
  return s + '</svg>';
}

export function ring(pct, over) {
  const r = 78, c = 2 * Math.PI * r, p = Math.max(0, Math.min(1, pct));
  return `<svg viewBox="0 0 180 180" class="ring"><circle cx="90" cy="90" r="${r}" class="ring-bg"/><circle cx="90" cy="90" r="${r}" class="ring-fg${over ? ' over' : ''}" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - p)}" transform="rotate(-90 90 90)"/></svg>`;
}
