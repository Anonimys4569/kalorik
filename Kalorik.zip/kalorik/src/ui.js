import { dkey } from './store.js';

export const ui = { tab: 'diary', date: dkey(), range: 7, meal: 'breakfast', filter: 'all', q: '' };
export const A = {};   // дії по кліку: data-a="name"
export const I = {};   // обробники введення: data-i="name"
export const C = {};   // обробники зміни: data-c="name"
export const app = { render: () => {} };

export const $ = (s, root = document) => root.querySelector(s);
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const num = v => { const n = parseFloat(String(v ?? '').replace(',', '.')); return Number.isFinite(n) ? n : 0; };
export const fmt = n => Math.round(n).toLocaleString('uk-UA');

export const MEALS = [
  { id: 'breakfast', name: 'Сніданок', icon: '🌅' }, { id: 'lunch', name: 'Обід', icon: '🍲' },
  { id: 'dinner', name: 'Вечеря', icon: '🌙' }, { id: 'snack', name: 'Перекус', icon: '🍎' },
];
const MONTHS = ['січня', 'лютого', 'березня', 'квітня', 'травня', 'червня', 'липня', 'серпня', 'вересня', 'жовтня', 'листопада', 'грудня'];
const WD = ['нд', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
export const dateLabel = d => `${WD[d.getDay()]}, ${d.getDate()} ${MONTHS[d.getMonth()]}`;
export const shortDate = d => `${d.getDate()}.${String(d.getMonth() + 1).padStart(2, '0')}`;

let toastTimer;
export function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

// Нижня шторка. Кнопка «Назад» на Android закриває її через history.
let open = false, onClose = null;
export function sheet(html, opts = {}) {
  const root = $('#sheet-root');
  if (onClose) { onClose(); onClose = null; }
  root.innerHTML = `<div class="backdrop" data-a="closeSheet"></div><div class="sheet${opts.full ? ' full' : ''}"><div class="grab"></div>${html}</div>`;
  onClose = opts.onClose || null;
  if (!open) { open = true; history.pushState({ sheet: 1 }, ''); }
  requestAnimationFrame(() => root.classList.add('open'));
}
export function closeSheet() { if (open) history.back(); }
window.addEventListener('popstate', () => {
  if (!open) return;
  open = false;
  if (onClose) { onClose(); onClose = null; }
  const root = $('#sheet-root');
  root.classList.remove('open');
  setTimeout(() => { if (!open) root.innerHTML = ''; }, 220);
});
A.closeSheet = closeSheet;

const find = (e, attr) => e.target.closest?.(`[${attr}]`);
document.addEventListener('click', e => { const el = find(e, 'data-a'); if (el && A[el.dataset.a]) A[el.dataset.a](el, e); });
document.addEventListener('input', e => { const el = find(e, 'data-i'); if (el && I[el.dataset.i]) I[el.dataset.i](el, e); });
document.addEventListener('change', e => { const el = find(e, 'data-c'); if (el && C[el.dataset.c]) C[el.dataset.c](el, e); });
