import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { S } from './store.js';

export const canNotify = () => Capacitor.isNativePlatform();
const MEALS = ['Час поснідати', 'Час пообідати', 'Час повечеряти'];

// Нагадування повністю локальні: їх показує сам телефон, інтернет і сервер не потрібні.
export async function applyReminders() {
  if (!canNotify()) return false;
  const r = S.settings.reminders;
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) await LocalNotifications.cancel({ notifications: pending.notifications.map(n => ({ id: n.id })) });
  if (!r.meals && !r.water) return true;
  let perm = await LocalNotifications.checkPermissions();
  if (perm.display !== 'granted') perm = await LocalNotifications.requestPermissions();
  if (perm.display !== 'granted') return false;
  const list = [];
  if (r.meals) r.times.forEach((t, i) => {
    const [hour, minute] = t.split(':').map(Number);
    list.push({ id: 100 + i, title: MEALS[i], body: 'Не забудь записати їжу в щоденник', schedule: { on: { hour, minute }, allowWhileIdle: true } });
  });
  if (r.water) for (let h = r.waterFrom, i = 0; h <= r.waterTo; h += Math.max(1, r.waterEvery), i++) {
    list.push({ id: 200 + i, title: 'Випий води', body: 'Склянка води — і відміть її в щоденнику', schedule: { on: { hour: h, minute: 0 }, allowWhileIdle: true } });
  }
  await LocalNotifications.schedule({ notifications: list });
  return true;
}
