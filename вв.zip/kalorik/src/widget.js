import { Capacitor, registerPlugin } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';
import { App } from '@capacitor/app';
import { S, dkey, totals, streak } from './store.js';
import { norm } from './calc.js';
import { lang } from './i18n.js';

const KW = registerPlugin('KalorikWidget');
const native = Capacitor.getPlatform() === 'android';
let timer = null;

// Віджет читає короткий підсумок із сховища телефону — сервер не потрібен.
export function syncWidget() {
  if (!native) return;
  clearTimeout(timer);
  timer = setTimeout(async () => {
    try {
      const n = norm(S.profile), t = totals(dkey());
      await Preferences.set({ key: 'kalorik_widget', value: JSON.stringify({
        date: dkey(), norm: n.kcal, eaten: Math.round(t.kcal), burned: Math.round(t.burned),
        p: Math.round(t.p), pn: n.p, streak: streak(), lang: lang(),
      }) });
      await KW.refresh();
    } catch (e) { /* віджет не критичний */ }
  }, 500);
}

// Кнопки віджета відкривають програму через kalorik://add або kalorik://voice (а в вебі — ?action=…).
export function listenLinks(handler) {
  const act = new URLSearchParams(location.search).get('action');
  if (act) { history.replaceState(null, '', location.pathname); setTimeout(() => handler(act), 300); }
  if (!Capacitor.isNativePlatform()) return;
  const go = url => { const m = /^kalorik:\/\/(\w+)/.exec(url || ''); if (m) handler(m[1]); };
  App.addListener('appUrlOpen', e => go(e.url));
  App.getLaunchUrl().then(r => go(r?.url)).catch(() => {});
}
