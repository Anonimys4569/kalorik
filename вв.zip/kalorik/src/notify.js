import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { S } from './store.js';
import { t } from './i18n.js';

export const canNotify = () => Capacitor.isNativePlatform();

// Нагадування повністю локальні: їх показує сам телефон, інтернет і сервер не потрібні.
export async function applyReminders() {
  if (!canNotify()) return false;
  const r = S.settings.reminders;
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length) await LocalNotifications.cancel({ notifications: pending.notifications.map(n => ({ id: n.id })) });
  if (!r.meals && !r.water && !r.week) return true;
  let perm = await LocalNotifications.checkPermissions();
  if (perm.display !== 'granted') perm = await LocalNotifications.requestPermissions();
  if (perm.display !== 'granted') return false;
  const titles = [t('Час поснідати'), t('Час пообідати'), t('Час повечеряти')];
  const list = [];
  if (r.meals) r.times.forEach((tm, i) => {
    const [hour, minute] = tm.split(':').map(Number);
    list.push({ id: 100 + i, title: titles[i], body: t('Не забудь записати їжу в щоденник'), schedule: { on: { hour, minute }, allowWhileIdle: true } });
  });
  if (r.water) for (let h = r.waterFrom, i = 0; h <= r.waterTo; h += Math.max(1, r.waterEvery), i++) {
    list.push({ id: 200 + i, title: t('Випий води'), body: t('Склянка води — і відміть її в щоденнику'), schedule: { on: { hour: h, minute: 0 }, allowWhileIdle: true } });
  }
  // У Capacitor weekday 1 = неділя.
  if (r.week) list.push({ id: 300, title: t('Підсумок тижня готовий'), body: t('Подивись, як минув твій тиждень'), schedule: { on: { weekday: 1, hour: 19, minute: 0 }, allowWhileIdle: true } });
  await LocalNotifications.schedule({ notifications: list });
  return true;
}
