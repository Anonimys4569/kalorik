import { t } from './i18n.js';

// Розрахунок денної норми: формула Міффліна — Сан-Жеора × коефіцієнт активності.
export const ACTIVITY = [
  { id: 'sed', k: 1.2, get name() { return t('Сидячий'); }, get hint() { return t('офіс, майже без руху'); } },
  { id: 'light', k: 1.375, get name() { return t('Легка активність'); }, get hint() { return t('тренування 1–3 рази на тиждень'); } },
  { id: 'mid', k: 1.55, get name() { return t('Середня активність'); }, get hint() { return t('тренування 3–5 разів на тиждень'); } },
  { id: 'high', k: 1.725, get name() { return t('Висока активність'); }, get hint() { return t('тренування 6–7 разів на тиждень'); } },
  { id: 'max', k: 1.9, get name() { return t('Дуже висока'); }, get hint() { return t('фізична робота або спорт щодня'); } },
];
export const GOALS = [
  { id: 'lose', get name() { return t('Схуднення'); }, delta: -0.15, protein: 2.0 },
  { id: 'keep', get name() { return t('Підтримка ваги'); }, delta: 0, protein: 1.6 },
  { id: 'gain', get name() { return t('Набір ваги'); }, delta: 0.15, protein: 1.8 },
];

export function bmr(p) {
  const base = 10 * p.weight + 6.25 * p.height - 5 * p.age;
  return p.sex === 'f' ? base - 161 : base + 5;
}
export function tdee(p) {
  const act = ACTIVITY.find(a => a.id === p.activity) || ACTIVITY[1];
  return bmr(p) * act.k;
}

// Орієнтири для клітковини, цукру й солі. Клітковина — 14 г на 1000 ккал (так радять ВООЗ/EFSA),
// цукор — не більше 10 % калорій, сіль — не більше 5 г на день (ВООЗ).
export const microNorm = kcal => ({ fi: Math.round(kcal * 14 / 1000), su: Math.round(kcal * 0.1 / 4), sa: 5 });

export function norm(p) {
  if (p.manual) return { ...p.manual, ...microNorm(p.manual.kcal), water: waterNorm(p), auto: false };
  const goal = GOALS.find(g => g.id === p.goal) || GOALS[1];
  const td = tdee(p);
  const floor = p.sex === 'f' ? 1200 : 1500; // нижче не опускаємо — це небезпечно для здоров'я
  const kcal = Math.max(floor, Math.round(td * (1 + goal.delta) / 10) * 10);
  const prot = Math.round(goal.protein * p.weight);
  const fat = Math.round(kcal * 0.27 / 9);
  const carb = Math.max(0, Math.round((kcal - prot * 4 - fat * 9) / 4));
  return { kcal, p: prot, f: fat, c: carb, ...microNorm(kcal), water: waterNorm(p), auto: true, bmr: Math.round(bmr(p)), tdee: Math.round(td) };
}

export const waterNorm = p => Math.round(p.weight * 30 / 50) * 50; // мл, 30 мл на кг

// Активності: MET × вага (кг) × години = ккал
export const ACTS = [
  ['Ходьба', 3.5], ['Швидка ходьба', 4.5], ['Біг', 9.0], ['Велосипед', 7.0], ['Силове тренування', 5.0],
  ['Плавання', 7.0], ['Футбол', 7.5], ['Баскетбол', 6.5], ['Йога / розтяжка', 2.8], ['Танці', 5.0],
  ['Прибирання', 3.3], ['Скакалка', 10.0], ['Домашнє тренування', 4.5], ['Робота на городі', 4.0],
];
export const actKcal = (met, kg, min) => Math.round(met * kg * min / 60);

export const r1 = x => Math.round(x * 10) / 10;
export function scale(food, g) {
  const k = g / 100;
  return { kcal: Math.round(food.kcal * k), p: r1((food.p || 0) * k), f: r1((food.f || 0) * k), c: r1((food.c || 0) * k),
    fi: r1((food.fi || 0) * k), su: r1((food.su || 0) * k), sa: Math.round((food.sa || 0) * k * 100) / 100 };
}

// Перевірка калорій за БЖВ (коефіцієнти Атуотера 4/9/4). Якщо ШІ дав калорії, що сильно не збігаються
// з БЖВ, беремо значення, пораховане з БЖВ, — воно надійніше за «на око».
export function reconcile(i) {
  const calc = i.p * 4 + i.f * 9 + i.c * 4;
  if (calc < 20 || !i.kcal) return { ...i, fixed: false };
  const dev = Math.abs(i.kcal - calc) / calc;
  return dev > 0.25 ? { ...i, kcal: Math.round(calc), fixed: true } : { ...i, fixed: false };
}

/* ---------- Цільова вага й прогноз ---------- */
// Лінійна регресія ваги за останні 28 днів → кг на тиждень.
export function weightTrend(weights, todayKey, parse) {
  const t0 = parse(todayKey).getTime(), pts = weights.map(w => ({ x: (parse(w.d).getTime() - t0) / 864e5, y: w.kg })).filter(p => p.x >= -28);
  if (pts.length < 2 || pts[pts.length - 1].x - pts[0].x < 6) return null;
  const n = pts.length, mx = pts.reduce((s, p) => s + p.x, 0) / n, my = pts.reduce((s, p) => s + p.y, 0) / n;
  const den = pts.reduce((s, p) => s + (p.x - mx) ** 2, 0);
  if (!den) return null;
  return pts.reduce((s, p) => s + (p.x - mx) * (p.y - my), 0) / den * 7;
}
// Прогноз за калоріями: (середній баланс за день) × 7 / 7700 ккал на кг жиру.
export function calorieRate(avgNet, tdeeVal) { return (avgNet - tdeeVal) * 7 / 7700; }
// Скільки днів до цілі при швидкості kgPerWeek (null, якщо рухаємось не в той бік).
export function daysToGoal(cur, goal, kgPerWeek) {
  const diff = goal - cur;
  if (Math.abs(diff) < 0.05) return 0;
  if (!kgPerWeek || Math.sign(kgPerWeek) !== Math.sign(diff) || Math.abs(kgPerWeek) < 0.02) return null;
  return Math.ceil(Math.abs(diff) / Math.abs(kgPerWeek) * 7);
}
