import { S } from './store.js';
import { ROWS } from './dict.js';

// Ключ — український текст. Для укр. беремо його як є, для англ. і рос. шукаємо переклад у словнику.
export const LANGS = [['uk', 'Українська'], ['en', 'English'], ['ru', 'Русский']];
const LOCALE = { uk: 'uk-UA', en: 'en-GB', ru: 'ru-RU' };
const DICT = new Map(ROWS.map(([uk, en, ru]) => [uk, { en, ru }]));

export function detectLang() {
  const n = (navigator.language || 'uk').slice(0, 2).toLowerCase();
  return n === 'ru' || n === 'en' ? n : 'uk';
}
export const lang = () => S.settings.lang || detectLang();
export const locale = () => LOCALE[lang()];

export function t(key, ...args) {
  const l = lang();
  let s = key;
  if (l !== 'uk') { const e = DICT.get(key); if (e && e[l]) s = e[l]; }
  return args.length ? s.replace(/\{(\d+)\}/g, (_, i) => args[i] ?? '') : s;
}

// Множина: key = "день|дні|днів"; англійська бере 2 форми, укр./рос. — 3.
export function pl(n, key) {
  const forms = t(key).split('|'), l = lang();
  if (l === 'en') return n === 1 ? forms[0] : forms[1] || forms[0];
  const m = n % 10, h = n % 100;
  return m === 1 && h !== 11 ? forms[0] : m >= 2 && m <= 4 && (h < 12 || h > 14) ? forms[1] : forms[2];
}

export const fmt = n => Math.round(n).toLocaleString(locale());
export const fmt1 = n => (Math.round(n * 10) / 10).toLocaleString(locale(), { maximumFractionDigits: 1 });
const dtf = (d, o) => new Intl.DateTimeFormat(locale(), o).format(d);
export const dateLabel = d => dtf(d, { weekday: 'short', day: 'numeric', month: 'long' });
export const shortDate = d => dtf(d, { day: '2-digit', month: '2-digit' });
export const weekdayShort = d => dtf(d, { weekday: 'short' });
export const longDate = d => dtf(d, { day: 'numeric', month: 'long', year: 'numeric' });

// Назва продукту з вбудованого каталогу — мовою інтерфейсу.
export const fname = f => (f.tr && f.tr[lang()]) || f.name;
